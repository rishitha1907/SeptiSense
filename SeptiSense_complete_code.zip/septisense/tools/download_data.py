"""Download the PhysioNet 2019 sepsis training data on Windows (no wget needed).

    python tools/download_data.py                 # -> physionet_training/training_setA, training_setB

Resumable: re-run it and already-downloaded files are skipped.
"""
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import urljoin

import requests
from requests.adapters import HTTPAdapter, Retry

BASE = "https://physionet.org/files/challenge-2019/1.0.0/training/"
OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "physionet_training")

s = requests.Session()
s.mount("https://", HTTPAdapter(max_retries=Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504]),
                                pool_maxsize=16))


def list_files(folder):
    html = s.get(urljoin(BASE, folder + "/"), timeout=60).text
    names = sorted(set(re.findall(r'href="(?:[^"]*/)?([^"/]+\.psv)"', html)))
    return names


def fetch(folder, name):
    dst = OUT / folder / name
    if dst.exists() and dst.stat().st_size > 0:
        return
    r = s.get(urljoin(BASE, f"{folder}/{name}"), timeout=60)
    r.raise_for_status()
    dst.write_bytes(r.content)


for folder in ["training_setA", "training_setB"]:
    (OUT / folder).mkdir(parents=True, exist_ok=True)
    names = list_files(folder)
    print(f"{folder}: {len(names)} files")
    if not names:
        sys.exit("Could not read the file list - check internet / open the URL in a browser: " + BASE + folder)
    done = 0
    with ThreadPoolExecutor(max_workers=16) as ex:
        futs = [ex.submit(fetch, folder, n) for n in names]
        for f in as_completed(futs):
            f.result()
            done += 1
            if done % 1000 == 0 or done == len(names):
                print(f"  {done}/{len(names)}")
print(f"Done -> {OUT.resolve()}")
