"""Fake ESP32 for testing the backend without hardware. Sends 1 packet/sec with realistic NOISE:
spikes, finger-off episodes, ECG leads-off, Wi-Fi dropouts with offline buffering + flush.

    python tools/fake_esp.py                                   # normal patient, noisy
    python tools/fake_esp.py --scenario deteriorating --ecg    # HR/temp rise, SpO2 falls; raw ECG too
    python tools/fake_esp.py --clean                           # no injected noise
"""
import argparse
import math
import random
import time

import requests


def ecg_chunk(t0, hr, fs=250, n=250):
    """Synthetic ECG: R-peaks + baseline wander + 50 Hz mains hum + noise."""
    out, rr = [], 60.0 / hr
    for i in range(n):
        t = t0 + i / fs
        phase = (t % rr) / rr
        qrs = 1.2 * math.exp(-((phase - 0.3) ** 2) / 0.0004)
        twave = 0.25 * math.exp(-((phase - 0.6) ** 2) / 0.004)
        out.append(round(qrs + twave + 0.3 * math.sin(2 * math.pi * 0.3 * t)
                         + 0.15 * math.sin(2 * math.pi * 50 * t) + random.gauss(0, 0.03), 4))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8000/api/telemetry")
    ap.add_argument("--device", default="esp32-01")
    ap.add_argument("--scenario", default="normal", choices=["normal", "deteriorating"])
    ap.add_argument("--duration", type=int, default=600, help="seconds")
    ap.add_argument("--ecg", action="store_true", help="also send raw ECG samples (250 Hz)")
    ap.add_argument("--clean", action="store_true", help="disable injected noise")
    a = ap.parse_args()

    seq, buffer, offline_until = 0, [], 0
    t_start = time.time()
    while time.time() - t_start < a.duration:
        el = time.time() - t_start
        frac = min(el / a.duration, 1.0) if a.scenario == "deteriorating" else 0.0
        hr = 78 + 40 * frac + random.gauss(0, 1.5)
        spo2 = 98 - 6 * frac + random.gauss(0, 0.6)
        skin = 34.0 + 1.6 * frac + random.gauss(0, 0.05)
        hr_ecg = hr + random.gauss(0, 1.0)
        pkt = {"device_id": a.device, "seq": seq, "ts": time.time(), "hr": round(hr, 1), "spo2": round(min(spo2, 100), 1),
               "temp": round(skin, 2), "hr_ecg": None if a.ecg else round(hr_ecg, 1), "finger_on": True, "leads_off": False}
        if not a.clean:
            r = random.random()
            if r < 0.04:
                pkt["hr"] = round(hr + random.choice([-1, 1]) * random.uniform(40, 80), 1)    # motion spike
            elif r < 0.06:
                pkt["spo2"] = random.choice([0, 55.0])                                         # algorithm glitch
            if 120 <= el % 300 < 135:                                                         # finger off for 15 s
                pkt["finger_on"], pkt["hr"], pkt["spo2"] = False, 0, 0
            if 200 <= el % 300 < 206:
                pkt["leads_off"] = True
        if a.ecg:
            pkt["ecg"] = ecg_chunk(el, hr)
            pkt["ecg_fs"] = 250
        seq += 1

        if not a.clean and 240 <= el % 300 < 260:          # Wi-Fi drops for 20 s -> buffer locally
            offline_until = time.time() + 1
        if time.time() < offline_until:
            pkt["buffered"] = True
            buffer.append(pkt)
            print(f"[offline] buffered {len(buffer)}")
        else:
            try:
                payload = buffer + [pkt] if buffer else pkt
                resp = requests.post(a.url, json=payload, timeout=3).json()
                if buffer:
                    print(f"[flush] sent {len(buffer)} buffered packets")
                buffer = []
                print(f"seq {seq - 1} hr {pkt['hr']} spo2 {pkt['spo2']} temp {pkt['temp']} -> ack {resp['ack']} level {resp['level']}")
            except Exception as e:
                buffer.append(dict(pkt, buffered=True))
                print("[no ack] laptop unreachable -> buffering; ESP would use local thresholds + buzzer:", e)
        time.sleep(max(0, 1 - (time.time() - t_start - el)))


if __name__ == "__main__":
    main()
