"""Platt calibration. The model is trained with class weights (to handle imbalance),
which inflates raw probabilities; this maps them back to realistic probabilities.
Fitted on the VALIDATION set only (never test)."""
import numpy as np
from sklearn.linear_model import LogisticRegression


class PlattCalibrator:
    def fit(self, raw, y):
        self.lr = LogisticRegression(C=1e6, max_iter=1000)
        self.lr.fit(self._logit(raw).reshape(-1, 1), y)
        return self

    def predict(self, raw):
        return self.lr.predict_proba(self._logit(np.asarray(raw)).reshape(-1, 1))[:, 1]

    @staticmethod
    def _logit(p):
        p = np.clip(np.asarray(p, dtype=float), 1e-6, 1 - 1e-6)
        return np.log(p / (1 - p))
