"""SMOKE-TEST ONLY: writes fake patients in the exact PhysioNet .psv format so the pipeline
can be tested before the real download finishes. Never report results from this data.

    python -m ml.synth --out /tmp/fake_physionet --n 1500
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from .data import ALL_COLUMNS


def make_patient(rng, septic):
    n = int(rng.integers(24, 90))
    onset = int(rng.integers(14, n + 4)) if septic else None
    hr = rng.normal(82, 8) + rng.normal(0, 4, n)
    o2 = np.clip(rng.normal(97, 1.2) + rng.normal(0, 1, n), 80, 100)
    temp = rng.normal(37.0, 0.3) + rng.normal(0, 0.2, n)
    resp = rng.normal(17, 2) + rng.normal(0, 1.5, n)
    if septic:
        ramp = np.clip((np.arange(n) - (onset - 12)) / 12, 0, None)
        hr += ramp * rng.uniform(15, 30); temp += ramp * rng.uniform(0.6, 1.4)
        o2 -= ramp * rng.uniform(1, 4); resp += ramp * rng.uniform(3, 8)
    d = pd.DataFrame(np.nan, index=range(n), columns=ALL_COLUMNS)
    d["HR"], d["O2Sat"], d["Temp"], d["Resp"] = hr, o2, temp, resp
    d.loc[rng.random(n) < 0.1, "HR"] = np.nan
    d.loc[rng.random(n) < 0.15, "O2Sat"] = np.nan
    d.loc[rng.random(n) < 0.7, "Temp"] = np.nan
    d["Age"], d["Gender"] = round(float(rng.uniform(20, 90)), 2), int(rng.integers(0, 2))
    d["ICULOS"] = np.arange(1, n + 1)
    d["SepsisLabel"] = 0
    if septic:
        d.loc[np.arange(n) >= onset - 6, "SepsisLabel"] = 1
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--n", type=int, default=1500)
    a = ap.parse_args()
    rng = np.random.default_rng(1)
    for i in range(a.n):
        folder = Path(a.out) / ("training_setA" if i % 2 == 0 else "training_setB")
        folder.mkdir(parents=True, exist_ok=True)
        make_patient(rng, rng.random() < 0.08).to_csv(folder / f"p{i:06d}.psv", sep="|", index=False)
    print(f"wrote {a.n} fake patients to {a.out}")


if __name__ == "__main__":
    main()
