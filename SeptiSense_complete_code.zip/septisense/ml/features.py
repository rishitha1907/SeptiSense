"""Feature engineering shared by TRAINING and the LIVE BACKEND.
Both must call build_features() so the model sees identical inputs.

Input : dataframe with columns pid, hour, <vitals...>, Age, Gender  (one row per patient-hour)
Output: same rows + engineered feature columns. Never uses future rows (no leakage):
        only forward-fill and trailing rolling windows.
"""
import numpy as np
import pandas as pd

NORMAL = {"HR": (60, 100), "O2Sat": (95, 100), "Temp": (36.1, 37.8), "Resp": (12, 20),
          "SBP": (90, 140), "MAP": (65, 105), "DBP": (60, 90), "EtCO2": (35, 45)}


def _roll(g, w, fn):
    return getattr(g.rolling(w, min_periods=1), fn)().reset_index(level=0, drop=True)


def build_features(df, rolling_vars, ffill_only_vars=(), static=("Age", "Gender")):
    df = df.sort_values(["pid", "hour"]).reset_index(drop=True)
    pid = df["pid"]
    new, feats = {}, []
    for v in list(rolling_vars) + list(ffill_only_vars):
        raw = df[v] if v in df else pd.Series(np.nan, index=df.index)
        measured = raw.notna()
        last_meas_hour = df["hour"].where(measured).groupby(pid).ffill()
        filled = raw.groupby(pid).ffill()                       # forward fill only (past -> present)
        new[v] = filled
        new[f"{v}_miss"] = (~measured).astype(np.int8)
        new[f"{v}_since"] = df["hour"] - last_meas_hour         # NaN if never measured
        feats += [v, f"{v}_miss", f"{v}_since"]
        if v in rolling_vars:
            g = filled.groupby(pid)
            new[f"{v}_mean6"] = _roll(g, 6, "mean")
            new[f"{v}_std6"] = _roll(g, 6, "std")
            new[f"{v}_min6"] = _roll(g, 6, "min")
            new[f"{v}_max6"] = _roll(g, 6, "max")
            new[f"{v}_mean12"] = _roll(g, 12, "mean")
            new[f"{v}_d1"] = filled - g.shift(1)
            new[f"{v}_d6"] = filled - g.shift(6)
            feats += [f"{v}_{s}" for s in ("mean6", "std6", "min6", "max6", "mean12", "d1", "d6")]
    for s in static:
        new[s] = df[s] if s in df else pd.Series(np.nan, index=df.index)
        feats.append(s)
    keep = df.drop(columns=[c for c in new if c in df])
    out = pd.concat([keep, pd.DataFrame(new, index=df.index)], axis=1)
    return out, feats
