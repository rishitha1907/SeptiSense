"""Inference wrapper used by the backend. Loads artifacts written by ml/train.py."""
import json
import pickle
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd

from .features import build_features
from .explain import top_reasons


class SepsisModel:
    def __init__(self, artifacts_dir):
        d = Path(artifacts_dir)
        self.info = json.loads((d / "model_info.json").read_text(encoding="utf-8"))
        self.features = self.info["features"]
        self.horizons = self.info["horizons"]
        self.main_h = self.info["main_horizon"]
        self.thresholds = self.info["thresholds"]
        self.boosters, self.calibrators = {}, {}
        for h in self.horizons:
            self.boosters[h] = lgb.Booster(model_file=str(d / f"model_{h}h.txt"))
            with open(d / f"calibrator_{h}h.pkl", "rb") as f:
                self.calibrators[h] = pickle.load(f)

    def featurize(self, hourly):
        df, _ = build_features(hourly, self.info["rolling_vars"], self.info["ffill_vars"], self.info["static"])
        return df

    def predict_frame(self, X):
        """Calibrated risks for every row, monotone across horizons (2h <= 4h <= 6h)."""
        out = {}
        prev = None
        for h in sorted(self.horizons):
            raw = self.boosters[h].predict(X[self.features])
            p = self.calibrators[h].predict(raw)
            if prev is not None:
                p = np.maximum(p, prev)
            out[h] = p
            prev = p
        return out

    def level_for(self, risk):
        t = self.thresholds
        if risk >= t["critical"]:
            return "critical"
        if risk >= t["warning"]:
            return "warning"
        if risk >= t["watch"]:
            return "watch"
        return "normal"

    def predict_latest(self, hourly):
        """hourly: rows (one per hour) for ONE patient: pid, hour, HR, O2Sat, Temp, [Resp], Age, Gender."""
        df = self.featurize(hourly)
        last = df.iloc[[-1]]
        risks = self.predict_frame(last)
        X = last[self.features]
        contrib = self.boosters[self.main_h].predict(X, pred_contrib=True)[0][:-1]  # drop bias term
        reasons = top_reasons(self.features, X.iloc[0].tolist(), contrib, k=3)
        r_main = float(risks[self.main_h][0])
        return {
            "risk": {f"{h}h": round(float(risks[h][0]), 4) for h in self.horizons},
            "main_horizon": f"{self.main_h}h",
            "level": self.level_for(r_main),
            "reasons": reasons,
            "hours_of_history": int(len(hourly)),
        }
