"""Load the PhysioNet/CinC 2019 sepsis data, build multi-horizon labels, split by patient."""
from pathlib import Path
import numpy as np
import pandas as pd

VITALS = ["HR", "O2Sat", "Temp", "SBP", "MAP", "DBP", "Resp", "EtCO2"]
LABS = ["BaseExcess", "HCO3", "FiO2", "pH", "PaCO2", "SaO2", "AST", "BUN",
        "Alkalinephos", "Calcium", "Chloride", "Creatinine", "Bilirubin_direct",
        "Glucose", "Lactate", "Magnesium", "Phosphate", "Potassium",
        "Bilirubin_total", "TroponinI", "Hct", "Hgb", "PTT", "WBC",
        "Fibrinogen", "Platelets"]
DEMO = ["Age", "Gender", "Unit1", "Unit2", "HospAdmTime", "ICULOS"]
ALL_COLUMNS = VITALS + LABS + DEMO + ["SepsisLabel"]


def load_physionet(path, max_patients=None, cache=True):
    """Load either
    - the official folder (training_setA/*.psv, training_setB/*.psv), or
    - a single combined CSV that has a Patient_ID column (Kaggle version).
    Returns one dataframe with columns: pid, hospital, hour, <40 vars>, SepsisLabel.
    """
    path = Path(path)
    cache_file = (path if path.is_dir() else path.parent) / "_septisense_cache.pkl"
    if cache and cache_file.exists() and max_patients is None:
        print(f"[data] loading cache {cache_file}")
        return pd.read_pickle(cache_file)

    if path.is_file():
        df = pd.read_csv(path)
        df = df.rename(columns={"Patient_ID": "pid"})
        df["pid"] = df["pid"].astype(str)
        df["hospital"] = "?"
        if max_patients:
            keep = df["pid"].drop_duplicates().iloc[:max_patients]
            df = df[df["pid"].isin(keep)]
    else:
        files = sorted(path.rglob("*.psv"))
        if not files:
            raise FileNotFoundError(f"No .psv files under {path}")
        if max_patients:
            rng = np.random.default_rng(0)
            files = list(rng.choice(files, size=min(max_patients, len(files)), replace=False))
        print(f"[data] reading {len(files)} patient files ...")
        parts = []
        for i, f in enumerate(files):
            d = pd.read_csv(f, sep="|")
            d["pid"] = f.stem
            d["hospital"] = "A" if "setA" in str(f.parent) else ("B" if "setB" in str(f.parent) else "?")
            parts.append(d)
            if (i + 1) % 5000 == 0:
                print(f"  {i + 1}/{len(files)}")
        df = pd.concat(parts, ignore_index=True)

    df = df.sort_values(["pid"], kind="stable")
    df["hour"] = df.groupby("pid").cumcount()      # row position = hours since ICU data start
    df = df.reset_index(drop=True)
    if cache and max_patients is None:
        df.to_pickle(cache_file)
    print(f"[data] {df['pid'].nunique()} patients, {len(df)} hourly rows")
    return df


def add_horizon_labels(df, horizons=(2, 4, 6)):
    """In the dataset, SepsisLabel=1 starts 6h BEFORE clinical onset (t_sepsis).
    So t_sepsis = first positive hour + 6. Label for horizon h:
        y_h = 1 if patient is septic and hour >= t_sepsis - h
    (y_6 reproduces the original SepsisLabel)."""
    first_pos = df["hour"].where(df["SepsisLabel"] == 1).groupby(df["pid"]).transform("min")
    df["septic_patient"] = first_pos.notna().astype(int)
    df["t_sepsis"] = first_pos + 6
    for h in horizons:
        df[f"y_{h}h"] = ((df["septic_patient"] == 1) & (df["hour"] >= df["t_sepsis"] - h)).astype(int)
    return df


def split_patients(df, mode="random", seed=42, frac=(0.70, 0.15, 0.15)):
    """Patient-level split so no patient is in two sets (prevents leakage).
    mode='random'   : stratified 70/15/15 by septic status
    mode='hospital' : train/val from hospital A, test = hospital B (external validation)
    """
    pts = df.groupby("pid").agg(septic=("septic_patient", "max"), hospital=("hospital", "first")).reset_index()
    rng = np.random.default_rng(seed)
    split = {}
    if mode == "hospital" and set(pts["hospital"]) >= {"A", "B"}:
        test_ids = set(pts.loc[pts["hospital"] == "B", "pid"])
        rest = pts[pts["hospital"] == "A"]
        for s, grp in rest.groupby("septic"):
            ids = grp["pid"].to_numpy().copy(); rng.shuffle(ids)
            n_val = int(round(len(ids) * 0.15))
            split.update({p: "val" for p in ids[:n_val]})
            split.update({p: "train" for p in ids[n_val:]})
        split.update({p: "test" for p in test_ids})
    else:
        for s, grp in pts.groupby("septic"):
            ids = grp["pid"].to_numpy().copy(); rng.shuffle(ids)
            n = len(ids); n_tr = int(round(n * frac[0])); n_va = int(round(n * frac[1]))
            split.update({p: "train" for p in ids[:n_tr]})
            split.update({p: "val" for p in ids[n_tr:n_tr + n_va]})
            split.update({p: "test" for p in ids[n_tr + n_va:]})
    df["split"] = df["pid"].map(split)
    return df
