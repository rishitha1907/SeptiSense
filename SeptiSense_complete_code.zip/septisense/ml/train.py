"""Train + evaluate SeptiSense models.

    python -m ml.train --data /path/to/physionet/training            # full run
    python -m ml.train --data ... --max-patients 5000                # quick run
    python -m ml.train --data ... --split hospital --full            # external test + all-feature comparison

Writes everything to artifacts/: models, calibrators, thresholds, metrics, plots, eval_report.md,
and demo_patients.csv (held-out test patients for the dashboard's replay mode).
"""
import argparse
import json
import pickle
import time
from datetime import datetime, timezone

import lightgbm as lgb
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss, confusion_matrix,
                             precision_recall_curve, roc_auc_score, roc_curve)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import config
from .calibration import PlattCalibrator
from .data import LABS, VITALS, add_horizon_labels, load_physionet, split_patients
from .features import build_features

# fixed categorical order (never cycled) + chart ink, from the reference palette
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, MUTED, SURF = "#0b0b0b", "#52514e", "#898781", "#fcfcfb"
plt.rcParams.update({"figure.facecolor": SURF, "axes.facecolor": SURF, "axes.edgecolor": MUTED,
                     "axes.labelcolor": INK2, "xtick.color": MUTED, "ytick.color": MUTED,
                     "text.color": INK, "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.6,
                     "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 2,
                     "font.size": 10, "legend.frameon": False})

LGB_PARAMS = dict(objective="binary", learning_rate=0.05, num_leaves=31, min_data_in_leaf=200,
                  feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, lambda_l2=1.0,
                  metric="average_precision", verbose=-1, seed=42)


def train_lgb(Xtr, ytr, Xva, yva):
    pos = max(int(ytr.sum()), 1)
    spw = min((len(ytr) - pos) / pos, 50.0)          # class weighting for imbalance
    params = dict(LGB_PARAMS, scale_pos_weight=spw)
    dtr, dva = lgb.Dataset(Xtr, ytr), lgb.Dataset(Xva, yva)
    booster = lgb.train(params, dtr, num_boost_round=2000, valid_sets=[dva],
                        callbacks=[lgb.early_stopping(100, verbose=False)])
    return booster, spw


def threshold_at_sensitivity(p, y, sens):
    pos = np.sort(p[y == 1])
    if len(pos) == 0:
        return 0.5
    return float(pos[int(np.floor((1 - sens) * len(pos)))])


def op_metrics(p, y, thr):
    pred = p >= thr
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"threshold": round(thr, 4),
            "sensitivity": round(tp / max(tp + fn, 1), 4), "specificity": round(tn / max(tn + fp, 1), 4),
            "precision": round(tp / max(tp + fp, 1), 4), "npv": round(tn / max(tn + fn, 1), 4),
            "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn)}


def alert_starts(above, n_up, n_down):
    """Same hysteresis rule as the backend: enter after n_up consecutive highs, leave after n_down lows."""
    state, up, down, starts = False, 0, 0, []
    for i, a in enumerate(above):
        if not state:
            up = up + 1 if a else 0
            if up >= n_up:
                state, down = True, 0
                starts.append(i)
        else:
            down = down + 1 if not a else 0
            if down >= n_down:
                state, up = False, 0
    return starts


def patient_level_sim(test, p, thr, n_list=(1, 2, 3)):
    """Early-warning view: % septic patients warned before onset, lead time, false alert rate."""
    t = test[["pid", "hour", "septic_patient", "t_sepsis"]].copy()
    t["p"] = p
    rows = []
    for n in n_list:
        detected, leads, fa_eps, nonsep_hours = 0, [], 0, 0
        n_sep = 0
        for pid, g in t.groupby("pid", sort=False):
            above = (g["p"].to_numpy() >= thr)
            hours = g["hour"].to_numpy()
            starts = alert_starts(above, n, n)
            if g["septic_patient"].iat[0] == 1:
                n_sep += 1
                ts = g["t_sepsis"].iat[0]
                early = [hours[s] for s in starts if hours[s] < ts]
                if early:
                    detected += 1
                    leads.append(ts - early[0])
            else:
                fa_eps += len(starts)
                nonsep_hours += len(g)
        rows.append({"consecutive_hours_required": n,
                     "septic_patients_warned_before_onset_pct": round(100 * detected / max(n_sep, 1), 1),
                     "median_lead_time_h": float(np.median(leads)) if leads else None,
                     "false_alert_episodes_per_nonseptic_patient_day": round(fa_eps / max(nonsep_hours / 24, 1e-9), 3)})
    return rows


def sirs_like_score(df):
    """Rule baseline using only what our sensors measure (no WBC): HR>90, Temp>38 or <36, [Resp>20]."""
    s = (df["HR"] > 90).astype(int) + ((df["Temp"] > 38) | (df["Temp"] < 36)).astype(int)
    if "Resp" in df:
        s += (df["Resp"] > 20).astype(int)
    return s.to_numpy().astype(float)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="PhysioNet training folder or combined CSV")
    ap.add_argument("--split", default="random", choices=["random", "hospital"])
    ap.add_argument("--max-patients", type=int, default=None)
    ap.add_argument("--full", action="store_true", help="also train an all-40-variable comparison model")
    args = ap.parse_args()
    out = config.ARTIFACTS
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    df = load_physionet(args.data, max_patients=args.max_patients)
    df = add_horizon_labels(df, config.HORIZONS)
    df = split_patients(df, mode=args.split)
    raw_cols = ["pid", "hour", "hospital", "split", "septic_patient", "t_sepsis"] + [f"y_{h}h" for h in config.HORIZONS]

    # ---------- sensor-only feature set (what the hardware can measure live) ----------
    rolling_vars, ffill_vars, static = list(config.SENSOR_VITALS), [], list(config.STATIC_FEATURES)
    base = df[raw_cols + rolling_vars + static + ["SepsisLabel"]].copy()
    feat_df, feats = build_features(base, rolling_vars, ffill_vars, static)
    tr, va, te = (feat_df[feat_df["split"] == s] for s in ("train", "val", "test"))
    print(f"[split] train {tr.pid.nunique()} / val {va.pid.nunique()} / test {te.pid.nunique()} patients; "
          f"{len(feats)} features")

    metrics = {"dataset": "PhysioNet/CinC Challenge 2019 (Reyna et al., 2019)", "split": args.split,
               "n_patients": {"train": int(tr.pid.nunique()), "val": int(va.pid.nunique()), "test": int(te.pid.nunique())},
               "n_rows": {"train": len(tr), "val": len(va), "test": len(te)},
               "positive_rate_test": {f"{h}h": round(float(te[f"y_{h}h"].mean()), 4) for h in config.HORIZONS},
               "features_used": rolling_vars + static, "horizons": {}}
    test_preds = {}
    prev_te = None
    for h in sorted(config.HORIZONS):
        y = f"y_{h}h"
        booster, spw = train_lgb(tr[feats], tr[y], va[feats], va[y])
        cal = PlattCalibrator().fit(booster.predict(va[feats]), va[y].to_numpy())
        p_te = cal.predict(booster.predict(te[feats]))
        if prev_te is not None:
            p_te = np.maximum(p_te, prev_te)          # keep 2h <= 4h <= 6h (same rule as live)
        prev_te = p_te
        test_preds[h] = p_te
        booster.save_model(str(out / f"model_{h}h.txt"))
        with open(out / f"calibrator_{h}h.pkl", "wb") as f:
            pickle.dump(cal, f)
        metrics["horizons"][f"{h}h"] = {"auroc": round(roc_auc_score(te[y], p_te), 4),
                                        "auprc": round(average_precision_score(te[y], p_te), 4),
                                        "brier": round(brier_score_loss(te[y], p_te), 4),
                                        "trees": booster.best_iteration, "scale_pos_weight": round(spw, 2)}
        print(f"[{h}h] test AUROC {metrics['horizons'][f'{h}h']['auroc']}  AUPRC {metrics['horizons'][f'{h}h']['auprc']}")

    # ---------- thresholds for alert levels: chosen on VALIDATION, reported on TEST ----------
    H = config.MAIN_HORIZON
    b_main = lgb.Booster(model_file=str(out / f"model_{H}h.txt"))
    with open(out / f"calibrator_{H}h.pkl", "rb") as f:
        cal_main = pickle.load(f)
    p_va = cal_main.predict(b_main.predict(va[feats]))
    thresholds = {lvl: threshold_at_sensitivity(p_va, va[f"y_{H}h"].to_numpy(), s)
                  for lvl, s in config.ALERT_LEVEL_SENSITIVITY.items()}
    thresholds = {"watch": thresholds["watch"],
                  "warning": max(thresholds["warning"], thresholds["watch"]),
                  "critical": max(thresholds["critical"], thresholds["warning"])}
    yte = te[f"y_{H}h"].to_numpy()
    p_main = test_preds[H]
    metrics["operating_points_test"] = {lvl: op_metrics(p_main, yte, thr) for lvl, thr in thresholds.items()}
    metrics["early_warning_sim_test"] = patient_level_sim(te, p_main, thresholds["warning"])

    # ---------- baselines ----------
    sirs = sirs_like_score(te)
    lr = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                       LogisticRegression(class_weight="balanced", max_iter=300))
    lr.fit(tr[feats], tr[f"y_{H}h"])
    p_lr = lr.predict_proba(te[feats])[:, 1]
    metrics["baselines_6h"] = {
        "sirs_like_rule": {"auroc": round(roc_auc_score(yte, sirs), 4), "auprc": round(average_precision_score(yte, sirs), 4)},
        "logistic_regression": {"auroc": round(roc_auc_score(yte, p_lr), 4), "auprc": round(average_precision_score(yte, p_lr), 4)},
    }

    # ---------- optional: all-variable model to show what limited sensors cost ----------
    if args.full:
        roll_full = VITALS
        fb = df[raw_cols + VITALS + LABS + static + ["SepsisLabel"]].copy()
        ff, ffeats = build_features(fb, roll_full, LABS, static)
        ftr, fva, fte = (ff[ff["split"] == s] for s in ("train", "val", "test"))
        fbst, _ = train_lgb(ftr[ffeats], ftr[f"y_{H}h"], fva[ffeats], fva[f"y_{H}h"])
        pf = fbst.predict(fte[ffeats])
        metrics["all_variables_6h"] = {"auroc": round(roc_auc_score(fte[f"y_{H}h"], pf), 4),
                                       "auprc": round(average_precision_score(fte[f"y_{H}h"], pf), 4),
                                       "n_features": len(ffeats)}

    # ---------- explanations: global importance from SHAP contributions ----------
    sample = te[feats].sample(min(5000, len(te)), random_state=0)
    contrib = b_main.predict(sample, pred_contrib=True)[:, :-1]
    imp = pd.Series(np.abs(contrib).mean(0), index=feats).sort_values(ascending=False)
    imp.to_csv(out / "feature_importance.csv", header=["mean_abs_shap"])

    make_plots(out, te, test_preds, p_lr, sirs, yte, p_main, thresholds, imp)

    # ---------- demo patients for replay mode (held-out TEST patients only) ----------
    demo_cols = ["pid", "hour", "septic_patient", "t_sepsis", "SepsisLabel"] + rolling_vars + static
    raw_te = df[df["split"] == "test"]
    tp = te.assign(p=p_main)
    cand = (tp[tp["septic_patient"] == 1].groupby("pid")
            .agg(t_sepsis=("t_sepsis", "first"), pmax=("p", "max")).reset_index())
    cand = cand[cand["t_sepsis"] >= 18].sort_values("pmax", ascending=False).head(4)
    nonsep = tp[tp["septic_patient"] == 0].groupby("pid").size()
    nonsep = nonsep[nonsep >= 30].index[:2].tolist()
    demo_ids = cand["pid"].tolist() + nonsep
    raw_te[raw_te["pid"].isin(demo_ids)][demo_cols].to_csv(out / "demo_patients.csv", index=False)

    info = {"features": feats, "rolling_vars": rolling_vars, "ffill_vars": ffill_vars, "static": static,
            "horizons": config.HORIZONS, "main_horizon": H,
            "thresholds": {k: round(v, 4) for k, v in thresholds.items()},
            "alert_level_sensitivity_targets": config.ALERT_LEVEL_SENSITIVITY,
            "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "metrics_summary": {k: metrics["horizons"][k] for k in metrics["horizons"]},
            "disclaimer": config.DISCLAIMER}
    (out / "model_info.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2, default=float), encoding="utf-8")
    write_report(out, metrics, info, imp)
    print(f"[done] {time.time() - t0:.0f}s -> {out}")


def make_plots(out, te, preds, p_lr, sirs, yte, p_main, thr, imp):
    H = config.MAIN_HORIZON
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    for i, h in enumerate(sorted(preds)):
        y = te[f"y_{h}h"]
        fpr, tpr, _ = roc_curve(y, preds[h]); axes[0].plot(fpr, tpr, color=C[i], label=f"LightGBM {h}h")
        pr, rc, _ = precision_recall_curve(y, preds[h]); axes[1].plot(rc, pr, color=C[i], label=f"LightGBM {h}h")
    for j, (name, p) in enumerate([("Logistic reg. 6h", p_lr), ("SIRS-like rule 6h", sirs)]):
        fpr, tpr, _ = roc_curve(yte, p); axes[0].plot(fpr, tpr, color=C[3 + j], label=name, linestyle="--")
        pr, rc, _ = precision_recall_curve(yte, p); axes[1].plot(rc, pr, color=C[3 + j], label=name, linestyle="--")
    axes[0].plot([0, 1], [0, 1], color=MUTED, linewidth=1)
    axes[0].set(title="ROC (held-out test patients)", xlabel="False positive rate", ylabel="True positive rate")
    axes[1].axhline(yte.mean(), color=MUTED, linewidth=1)
    axes[1].set(title="Precision–recall (grey = prevalence)", xlabel="Recall", ylabel="Precision")
    axes[0].legend(loc="lower right"); axes[1].legend(loc="upper right")
    fig.tight_layout(); fig.savefig(out / "roc_pr.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5, 4.6))
    fp, mp = calibration_curve(yte, p_main, n_bins=10, strategy="quantile")
    ax.plot([0, max(mp.max(), fp.max())], [0, max(mp.max(), fp.max())], color=MUTED, linewidth=1, label="Perfect")
    ax.plot(mp, fp, color=C[0], marker="o", markersize=5, label=f"LightGBM {H}h (Platt)")
    ax.set(title="Calibration (test)", xlabel="Predicted risk", ylabel="Observed rate"); ax.legend()
    fig.tight_layout(); fig.savefig(out / "calibration.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(4.6, 4))
    cm = confusion_matrix(yte, p_main >= thr["warning"], labels=[0, 1])
    ax.imshow(cm, cmap="Blues"); ax.grid(False)
    for (r, c_), v in np.ndenumerate(cm):
        ax.text(c_, r, f"{v:,}", ha="center", va="center", color=INK if v < cm.max() / 2 else "white")
    ax.set(xticks=[0, 1], yticks=[0, 1], xticklabels=["No alert", "Alert"], yticklabels=["No sepsis ≤6h", "Sepsis ≤6h"],
           title=f"Warning threshold {thr['warning']:.3f} (test rows)")
    fig.tight_layout(); fig.savefig(out / "confusion_matrix.png", dpi=150); plt.close(fig)

    top = imp.head(15)[::-1]
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.barh(top.index, top.values, color=C[0], height=0.6)
    ax.set(title="Top features (mean |SHAP|, 6h model)", xlabel="Mean |contribution| (log-odds)")
    ax.grid(axis="y", visible=False)
    fig.tight_layout(); fig.savefig(out / "feature_importance.png", dpi=150); plt.close(fig)


def write_report(out, m, info, imp):
    H = config.MAIN_HORIZON
    L = ["# SeptiSense – ML evaluation report", "",
         f"> {config.DISCLAIMER}", "",
         "## Setup",
         f"- **Dataset:** {m['dataset']}. Hourly ICU records, 40 variables, open access.",
         f"- **Prediction target:** sepsis onset (Sepsis-3, as labelled in the dataset) within the next "
         f"{', '.join(str(h) for h in config.HORIZONS)} hours, predicted every hour. Main alert model = {H}h.",
         f"- **Features:** only variables our hardware measures live: {', '.join(m['features_used'])} "
         "→ current value, missing flag, hours since measured, 6h/12h rolling mean/std/min/max, 1h and 6h change.",
         f"- **Split:** by patient ({m['split']}); train {m['n_patients']['train']}, val {m['n_patients']['val']}, "
         f"test {m['n_patients']['test']} patients. No patient appears in two sets.",
         "- **Leakage precautions:** patient-level split; forward-fill only (never backward); trailing windows only; "
         "calibration and alert thresholds fitted on validation, test touched once.",
         "- **Class imbalance:** LightGBM `scale_pos_weight`, then Platt calibration on validation so risks are real probabilities; "
         "AUPRC reported alongside AUROC.", "",
         "## Test results", "", "| Model | Horizon | AUROC | AUPRC | Brier | Positive rate |", "|---|---|---|---|---|---|"]
    for h, v in m["horizons"].items():
        L.append(f"| LightGBM (sensor vitals) | {h} | {v['auroc']} | {v['auprc']} | {v['brier']} | {m['positive_rate_test'][h]} |")
    b = m["baselines_6h"]
    L.append(f"| Logistic regression | {H}h | {b['logistic_regression']['auroc']} | {b['logistic_regression']['auprc']} | – | {m['positive_rate_test'][f'{H}h']} |")
    L.append(f"| SIRS-like rule | {H}h | {b['sirs_like_rule']['auroc']} | {b['sirs_like_rule']['auprc']} | – | {m['positive_rate_test'][f'{H}h']} |")
    if "all_variables_6h" in m:
        a = m["all_variables_6h"]
        L.append(f"| LightGBM, all 40 variables (reference) | {H}h | {a['auroc']} | {a['auprc']} | – | {m['positive_rate_test'][f'{H}h']} |")
    L += ["", f"## Alert levels ({H}h model; thresholds from validation, metrics on test rows)", "",
          "| Level | Threshold | Sensitivity | Specificity | Precision |", "|---|---|---|---|---|"]
    for lvl, v in m["operating_points_test"].items():
        L.append(f"| {lvl} | {v['threshold']} | {v['sensitivity']} | {v['specificity']} | {v['precision']} |")
    L += ["", "## Patient-level early warning (Warning threshold, test patients)", "",
          "| Consecutive hours required | Septic patients warned before onset | Median lead time | False alert episodes / non-septic patient-day |",
          "|---|---|---|---|"]
    for r in m["early_warning_sim_test"]:
        L.append(f"| {r['consecutive_hours_required']} | {r['septic_patients_warned_before_onset_pct']}% | "
                 f"{r['median_lead_time_h']} h | {r['false_alert_episodes_per_nonseptic_patient_day']} |")
    L += ["", "Requiring consecutive high-risk hours trades a little sensitivity for far fewer false alerts (alert-fatigue reduction).", "",
          "## Most important features", "", "| Feature | Mean abs SHAP |", "|---|---|"]
    for f, v in imp.head(10).items():
        L.append(f"| {f} | {v:.4f} |")
    L += ["", "## Plots", "", "![ROC/PR](roc_pr.png)", "![Calibration](calibration.png)",
          "![Confusion](confusion_matrix.png)", "![Importance](feature_importance.png)", "",
          "## Limitations",
          "- Trained on ICU data with clinical-grade monitors; our prototype uses low-cost sensors (skin temperature + offset, PPG SpO₂).",
          "- Only a few vitals; no labs (lactate, WBC), which carry much of the sepsis signal.",
          "- The dataset label is Sepsis-3 per the challenge definition; real onset timing is uncertain.",
          "- Not externally validated on our device's data. Not a clinical tool.", "",
          "**Citation:** Reyna MA et al. Early Prediction of Sepsis From Clinical Data: The PhysioNet/Computing in Cardiology "
          "Challenge 2019. Crit Care Med. 2020;48(2):210–217. Data: physionet.org/content/challenge-2019/1.0.0/"]
    (out / "eval_report.md").write_text("\n".join(L), encoding="utf-8")


if __name__ == "__main__":
    main()
