"""Turn per-prediction SHAP contributions into human-readable reasons.
LightGBM gives exact TreeSHAP values via booster.predict(X, pred_contrib=True),
so no extra 'shap' package is needed."""
import math
from .features import NORMAL

NAMES = {"HR": ("HR", " bpm", 0), "O2Sat": ("SpO₂", "%", 0), "Temp": ("Temp", "°C", 1),
         "Resp": ("Resp", "/min", 0), "SBP": ("Systolic BP", " mmHg", 0), "MAP": ("MAP", " mmHg", 0),
         "DBP": ("Diastolic BP", " mmHg", 0), "EtCO2": ("EtCO₂", " mmHg", 0)}


def _fmt(v, dec):
    return f"{v:.{dec}f}"


def _level_arrow(var, val):
    lo, hi = NORMAL.get(var, (-math.inf, math.inf))
    return "↑" if val > hi else ("↓" if val < lo else "→")


def describe(feature, value):
    """Return (vital, arrow, text) for one feature/value."""
    if feature == "Age":
        return "Age", "•", f"Age {value:.0f}"
    if feature == "Gender":
        return "Gender", "•", "Male" if value == 1 else "Female"
    var, _, kind = feature.partition("_")
    name, unit, dec = NAMES.get(var, (var, "", 2))
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return var, "?", f"{name}: no data"
    if kind == "":
        return var, _level_arrow(var, value), f"{name} {_fmt(value, dec)}{unit}"
    if kind in ("d1", "d6"):
        span = "last 1h" if kind == "d1" else "over 6h"
        if abs(value) < 10 ** -dec:
            return var, "→", f"{name} steady {span}"
        word, arrow = ("rising", "↑") if value > 0 else ("falling", "↓")
        return var, arrow, f"{name} {word} {_fmt(abs(value), dec)}{unit} {span}"
    if kind == "mean6":
        return var, _level_arrow(var, value), f"{name} avg {_fmt(value, dec)}{unit} over 6h"
    if kind == "mean12":
        return var, _level_arrow(var, value), f"{name} avg {_fmt(value, dec)}{unit} over 12h"
    if kind == "min6":
        return var, "↓", f"{name} dipped to {_fmt(value, dec)}{unit} (6h low)"
    if kind == "max6":
        return var, "↑", f"{name} peaked at {_fmt(value, dec)}{unit} (6h high)"
    if kind == "std6":
        return var, "~", f"{name} unstable (±{_fmt(value, dec)}{unit} over 6h)"
    if kind == "miss":
        return var, "?", f"{name} not measured this hour" if value == 1 else f"{name} measured this hour"
    if kind == "since":
        return var, "?", f"{name} last measured {value:.0f}h ago"
    return var, "•", f"{feature} = {value}"


def top_reasons(feature_names, values, contribs, k=3):
    """Pick the top-k risk-RAISING features, max one per vital so reasons are varied.
    Falls back to the largest-magnitude features if nothing raises risk."""
    items = sorted(zip(feature_names, values, contribs), key=lambda t: -t[2])
    pos = [t for t in items if t[2] > 0]
    pool = pos if pos else sorted(items, key=lambda t: -abs(t[2]))
    out, used = [], set()
    for f, v, c in pool:
        if v is None or (isinstance(v, float) and math.isnan(v)):
            continue                       # nothing meaningful to show for a missing value
        if f == "Gender" or (f.endswith("_std6") and abs(v) < 0.05):
            continue                       # not informative to show ("Male", "unstable ±0.0")
        var, arrow, text = describe(f, v)
        if var in used:
            continue
        used.add(var)
        out.append({"feature": f, "value": None if v is None or (isinstance(v, float) and math.isnan(v)) else round(float(v), 2),
                    "arrow": arrow, "text": text, "contribution": round(float(c), 4),
                    "effect": "raises risk" if c > 0 else "lowers risk"})
        if len(out) == k:
            break
    return out
