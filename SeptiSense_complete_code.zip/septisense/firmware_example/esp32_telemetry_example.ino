/*
  SeptiSense – ESP32 telemetry TEMPLATE for the hardware teammate.
  NOT compiled/tested here: the sensor-reading part is a placeholder. What matters is the
  contract with the backend: 1 packet/sec JSON, NTP timestamps, null (not 0) for bad data,
  offline buffering + flush, and local buzzer fallback when the laptop stops ACKing.

  Libraries: ArduinoJson (v7), WiFi + HTTPClient (ESP32 core), plus your sensor libs
  (SparkFun MAX3010x for MAX30102, OneWire/DallasTemperature or Adafruit MLX90614).
*/
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <time.h>

const char* WIFI_SSID = "your-hotspot";
const char* WIFI_PASS = "password";
const char* SERVER    = "http://192.168.1.10:8000/api/telemetry";   // laptop IP on the same Wi-Fi
const char* DEVICE_ID = "esp32-01";
const int   BUZZER_PIN = 25;
const int   LO_PLUS = 32, LO_MINUS = 33;      // AD8232 leads-off pins
const float SKIN_TO_CORE = 3.0;               // keep in sync with backend config

const int MAX_BUF = 300;                      // ~5 min of packets while Wi-Fi is down
String buf[MAX_BUF]; int bufHead = 0, bufCount = 0;
uint32_t seq = 0;
unsigned long lastAckMs = 0;
String serverLevel = "normal";

struct Reading { bool fingerOn; float hr, spo2, tempSkin; bool hrValid, spo2Valid, tempValid; };

Reading readSensors() {
  // ---- REPLACE with real sensor code ----
  // MAX30102: compute HR/SpO2 with the SparkFun/Maxim algorithm over ~4 s of samples.
  // fingerOn = IR value > ~50000 (tune it). If the algorithm says invalid -> set *Valid=false.
  Reading r = {true, 80, 97, 34.0, true, true, true};
  return r;
}

void putNumOrNull(JsonDocument& d, const char* k, bool ok, float v) { if (ok) d[k] = v; else d[k] = nullptr; }

String makePacket(const Reading& r, bool buffered) {
  JsonDocument d;
  d["device_id"] = DEVICE_ID;
  d["seq"] = seq++;
  time_t now = time(nullptr);
  if (now > 1600000000) d["ts"] = (double)now; else d["ts"] = nullptr;   // NTP not synced -> server time
  putNumOrNull(d, "hr",   r.fingerOn && r.hrValid,   r.hr);
  putNumOrNull(d, "spo2", r.fingerOn && r.spo2Valid, r.spo2);
  putNumOrNull(d, "temp", r.tempValid, r.tempSkin);
  d["finger_on"] = r.fingerOn;
  d["leads_off"] = (digitalRead(LO_PLUS) == 1 || digitalRead(LO_MINUS) == 1);
  if (buffered) d["buffered"] = true;
  String s; serializeJson(d, s); return s;
}

void bufferPush(const String& s) {
  int idx = (bufHead + bufCount) % MAX_BUF;
  if (bufCount == MAX_BUF) bufHead = (bufHead + 1) % MAX_BUF; else bufCount++;   // drop oldest when full
  buf[idx] = s;
}

bool sendJson(const String& body) {
  if (WiFi.status() != WL_CONNECTED) return false;
  HTTPClient http; http.setTimeout(2000);
  http.begin(SERVER); http.addHeader("Content-Type", "application/json");
  int code = http.POST(body);
  if (code == 200) {
    JsonDocument resp; deserializeJson(resp, http.getString());
    serverLevel = resp["level"] | "normal";
    lastAckMs = millis();
    http.end(); return true;
  }
  http.end(); return false;
}

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT); pinMode(LO_PLUS, INPUT); pinMode(LO_MINUS, INPUT);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  configTime(0, 0, "pool.ntp.org", "time.google.com");   // UTC epoch; backend handles display time
  // init sensors here
}

void loop() {
  static unsigned long last = 0;
  if (millis() - last < 1000) return;
  last = millis();

  Reading r = readSensors();
  String pkt = makePacket(r, false);            // late (buffered) packets are handled by their timestamp

  // Flush buffered packets together with the new one as a JSON array
  String body = pkt;
  if (bufCount > 0) {
    body = "[";
    int n = min(bufCount, 60);                  // send at most 60 old packets per request
    for (int i = 0; i < n; i++) body += buf[(bufHead + i) % MAX_BUF] + ",";
    body += pkt + "]";
    if (sendJson(body)) { bufHead = (bufHead + n) % MAX_BUF; bufCount -= n; }
    else bufferPush(pkt);
  } else if (!sendJson(body)) {
    bufferPush(pkt);
  }

  // Local alerting
  bool laptopDown = millis() - lastAckMs > 30000;
  bool localAlarm = false;
  if (laptopDown) {   // fallback: simple thresholds on the device itself
    float core = r.tempSkin + SKIN_TO_CORE;
    localAlarm = (r.fingerOn && r.spo2Valid && r.spo2 < 90) || (r.fingerOn && r.hrValid && r.hr > 130) || (r.tempValid && core > 39.0);
  } else {
    localAlarm = (serverLevel == "warning" || serverLevel == "critical");
  }
  digitalWrite(BUZZER_PIN, localAlarm && (millis() / 500) % 2);   // beep pattern
}
