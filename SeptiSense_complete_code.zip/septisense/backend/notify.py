"""Telegram push alerts + templated text summaries (no LLM: deterministic, offline, can't hallucinate).

Telegram setup (free):
 1. In Telegram open @BotFather -> /newbot -> copy the token.
 2. Run the backend with  TELEGRAM_BOT_TOKEN=<token>  (never commit the token to GitHub).
 3. Doctor and guardian each open your bot and press Start (a bot cannot message a phone
    number directly - the person must start the chat once).
 4. GET /api/telegram/updates shows their chat_id; save it with POST /api/patients/{id}/contacts.
"""
import json
import threading
import time
import urllib.parse
import urllib.request

import config
from . import db

LEVEL_ICON = {"watch": "🟡", "warning": "🟠", "critical": "🔴", "normal": "🟢"}


def _send_telegram(chat_id, text):
    if not config.TELEGRAM_BOT_TOKEN:
        return False, "no TELEGRAM_BOT_TOKEN set (logged only)"
    url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage"
    data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
    try:
        with urllib.request.urlopen(urllib.request.Request(url, data=data), timeout=10) as r:
            return True, r.read().decode()[:200]
    except Exception as e:  # network down at the venue etc. - never crash the backend
        return False, str(e)[:200]


def telegram_updates():
    if not config.TELEGRAM_BOT_TOKEN:
        return {"error": "TELEGRAM_BOT_TOKEN not set"}
    url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/getUpdates"
    with urllib.request.urlopen(url, timeout=10) as r:
        data = json.loads(r.read())
    chats = {}
    for u in data.get("result", []):
        m = u.get("message") or u.get("edited_message") or {}
        ch = m.get("chat", {})
        if ch:
            chats[ch["id"]] = {"chat_id": ch["id"], "name": " ".join(filter(None, [ch.get("first_name"), ch.get("last_name")])),
                               "username": ch.get("username"), "last_text": m.get("text")}
    return {"chats": list(chats.values())}


def alert_message(patient, alert, prediction, role):
    if role == "guardian":       # plain language, no percentages, no diagnosis
        return (f"SeptiSense: the care team has been asked to review {patient['name']} urgently.\n"
                "Please contact the ward / treating doctor for an update.\n"
                "This is an automated monitoring message, not a diagnosis.")
    reasons = json.loads(alert["reasons"] or "[]")
    why = "\n".join(f"  {r['arrow']} {r['text']}" for r in reasons) or "  (no detail)"
    risk = prediction or {}
    c = json.loads(alert.get("clinical") or "null")
    head = f"{LEVEL_ICON.get(alert['level'], '')} SeptiSense {alert['level'].upper()} – {patient['name']}"
    if role == "nurse" and not alert.get("doctor_notified"):
        head += " – BEDSIDE CHECK"
    lines = [head, f"ML sepsis risk (next 6h): {alert['risk'] * 100:.1f}%"]
    if risk:
        lines.append(f"2h {risk.get('risk_2h', 0) * 100:.1f}% · 4h {risk.get('risk_4h', 0) * 100:.1f}% · 6h {risk.get('risk_6h', 0) * 100:.1f}%")
    lines += ["Model factors:", why]
    if c:
        lines.append(f"Bedside: NEWS2 {c['news2']}{' (partial)' if c['news2_partial'] else ''} · qSOFA {c['qsofa']}/3"
                     + (f" · lactate {c['lactate']:g}" if c.get("lactate") is not None else ""))
        lines.append(c["summary"])
        from .clinical import suggested_checks
        lines.append("Suggested checks: " + "; ".join(suggested_checks(c)) + ".")
    if role == "nurse" and not alert.get("doctor_notified"):
        lines.append("Please assess the patient and enter BP / resp rate / consciousness (and lactate if available) "
                     "in SeptiSense. The doctor is paged automatically if criteria are met or if not acknowledged.")
    else:
        lines.append("Acknowledge on the dashboard.")
    lines.append("— Research prototype, not a diagnosis.")
    return "\n".join(lines)


def notify_alert(patient, alert, prediction, roles):
    """Send in a background thread so the alert engine never blocks on the network."""
    contacts = db.q("SELECT * FROM contacts WHERE patient_id=?", (patient["id"],))

    def run():
        for role in roles:
            targets = [c for c in contacts if c["role"] == role]
            if not targets:
                db.x("INSERT INTO notifications (ts,patient_id,alert_id,channel,role,recipient,message,ok,info) "
                     "VALUES (?,?,?,?,?,?,?,?,?)", (time.time(), patient["id"], alert["id"], "telegram", role, None,
                                                    alert_message(patient, alert, prediction, role), 0, f"no {role} contact registered"))
            for c in targets:
                msg = alert_message(patient, alert, prediction, role)
                ok, info = _send_telegram(c["telegram_chat_id"], msg) if c.get("telegram_chat_id") else (False, "no chat_id")
                db.x("INSERT INTO notifications (ts,patient_id,alert_id,channel,role,recipient,message,ok,info) "
                     "VALUES (?,?,?,?,?,?,?,?,?)", (time.time(), patient["id"], alert["id"], "telegram", role,
                                                    c.get("name"), msg, int(ok), info))
    threading.Thread(target=run, daemon=True).start()


def patient_summary(pid):
    """Plain-language summary built from a template – for doctor handover / guardian."""
    p = db.q1("SELECT * FROM patients WHERE id=?", (pid,))
    if not p:
        return None
    hourly = db.q("SELECT * FROM hourly WHERE patient_id=? ORDER BY hour", (pid,))
    preds = db.q("SELECT * FROM predictions WHERE patient_id=? ORDER BY ts", (pid,))
    alerts = db.q("SELECT * FROM alerts WHERE patient_id=? ORDER BY ts", (pid,))
    L = [f"Patient: {p['name']} (age {p['age']:.0f}, {'male' if p['gender'] == 1 else 'female'})" if p["age"] is not None
         else f"Patient: {p['name']}"]
    L.append(f"Monitoring: {len(hourly)} hour(s) of data ({'replay of held-out dataset patient' if p['mode'] == 'replay' else 'live sensors'}).")

    def rng(col, unit, dec=0):
        vals = [h[col] for h in hourly if h[col] is not None]
        if not vals:
            return None
        return f"{col_names[col]} {min(vals):.{dec}f}–{max(vals):.{dec}f}{unit} (latest {vals[-1]:.{dec}f}{unit})"
    col_names = {"HR": "Heart rate", "O2Sat": "SpO₂", "Temp": "Temperature", "Resp": "Resp. rate"}
    parts = [rng("HR", " bpm"), rng("O2Sat", "%"), rng("Temp", "°C", 1), rng("Resp", "/min")]
    parts = [s for s in parts if s]
    if parts:
        L.append("Vitals range: " + "; ".join(parts) + ".")
    if preds:
        last = preds[-1]
        L.append(f"Current sepsis risk (6h): {last['risk_6h'] * 100:.0f}% – level {last['level'].upper()}, "
                 f"confidence {last['confidence']}.")
        earlier = [x for x in preds if x["hour"] is not None and last["hour"] is not None and x["hour"] <= last["hour"] - 6]
        if earlier:
            d = (last["risk_6h"] - earlier[-1]["risk_6h"]) * 100
            trend = "rising" if d > 2 else ("falling" if d < -2 else "stable")
            L.append(f"Risk trend over the last 6 hours: {trend} ({d:+.0f} points).")
        reasons = json.loads(last["reasons"] or "[]")
        if reasons:
            L.append("Main factors: " + "; ".join(r["text"] for r in reasons) + ".")
    if alerts:
        acked = sum(1 for a in alerts if a["acked_at"])
        hi = max(alerts, key=lambda a: ["watch", "warning", "critical"].index(a["level"]))
        L.append(f"Alerts: {len(alerts)} raised (highest {hi['level'].upper()}), {acked} acknowledged.")
    else:
        L.append("Alerts: none raised.")
    wq = db.q1("SELECT AVG(quality) q, SUM(quality_level='Low') low, COUNT(*) n FROM windows WHERE patient_id=?", (pid,))
    if wq and wq["n"]:
        L.append(f"Data quality: average {wq['q']:.0f}/100; {wq['low']} of {wq['n']} one-minute windows were low quality.")
    L.append(config.DISCLAIMER)
    return "\n".join(L)
