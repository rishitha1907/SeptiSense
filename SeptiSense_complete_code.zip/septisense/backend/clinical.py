"""Bedside clinical scores used as the SECOND KEY for alerts (alert-fatigue reduction).

The ML model is sensitive but has low precision (~3-4 %). Before paging a doctor we check whether
standard bedside criteria agree. Inputs = latest sensor vitals + the latest nurse observations
(BP, resp rate, consciousness, supplemental O2, suspected infection, lactate).

- NEWS2 (Royal College of Physicians, 2017): 7 parameters. If some are not measured, the score
  is PARTIAL and says which parameters are missing - it never invents values.
- qSOFA (Sepsis-3, 2016): resp rate >= 22, systolic BP <= 100, altered mentation.
- Lactate >= 2 mmol/L and clinician-flagged suspected infection are strong sepsis signals.

Scores support clinical judgement; they are not a diagnosis.
"""
import time

from . import db

PARAMS = ["resp", "spo2", "o2", "sbp", "hr", "consciousness", "temp"]
PARAM_NAMES = {"resp": "Resp. rate", "spo2": "SpO₂", "o2": "Supplemental O₂", "sbp": "Systolic BP",
               "hr": "Heart rate", "consciousness": "Consciousness", "temp": "Temperature"}
OBS_FRESH_SEC = 6 * 3600        # live mode: nurse observations older than 6 h are ignored


def _news_part(name, v):
    if v is None:
        return None
    if name == "resp":
        return 3 if v <= 8 else 1 if v <= 11 else 0 if v <= 20 else 2 if v <= 24 else 3
    if name == "spo2":
        return 3 if v <= 91 else 2 if v <= 93 else 1 if v <= 95 else 0
    if name == "o2":
        return 2 if v else 0
    if name == "sbp":
        return 3 if v <= 90 else 2 if v <= 100 else 1 if v <= 110 else 0 if v <= 219 else 3
    if name == "hr":
        return 3 if v <= 40 else 1 if v <= 50 else 0 if v <= 90 else 1 if v <= 110 else 2 if v <= 130 else 3
    if name == "consciousness":
        return 0 if v == "alert" else 3
    if name == "temp":
        return 3 if v <= 35.0 else 1 if v <= 36.0 else 0 if v <= 38.0 else 1 if v <= 39.0 else 2
    return None


def latest_obs(patient):
    """Most recent value of each observation field (each field can come from a different entry)."""
    rows = db.q("SELECT * FROM observations WHERE patient_id=? ORDER BY ts DESC LIMIT 50", (patient["id"],))
    if patient["mode"] == "live":
        rows = [r for r in rows if time.time() - r["ts"] <= OBS_FRESH_SEC]
    out = {}
    for f in ("sbp", "resp", "consciousness", "on_oxygen", "suspected_infection", "lactate", "wbc"):
        for r in rows:
            if r[f] is not None:
                out[f] = r[f]
                out[f + "_ts"] = r["ts"]
                break
    return out


def _latest_vitals(patient):
    """Sensor vitals: latest non-missing hourly value within the last 6 hours (an observation set)."""
    rows = db.q("SELECT * FROM hourly WHERE patient_id=? ORDER BY hour DESC LIMIT 6", (patient["id"],))
    v = {}
    for col, key in (("HR", "hr"), ("O2Sat", "spo2"), ("Temp", "temp"), ("Resp", "resp")):
        v[key] = next((r[col] for r in rows if r[col] is not None), None)
    return v


def assess(patient):
    v = _latest_vitals(patient)
    o = latest_obs(patient)
    vals = {"hr": v["hr"], "spo2": v["spo2"], "temp": v["temp"],
            "resp": o.get("resp", v["resp"]), "sbp": o.get("sbp"),
            "consciousness": o.get("consciousness"),
            "o2": None if o.get("on_oxygen") is None else bool(o["on_oxygen"])}
    parts = {k: _news_part(k, vals[k]) for k in PARAMS}
    measured = [k for k in PARAMS if parts[k] is not None]
    missing = [k for k in PARAMS if parts[k] is None]
    news2 = sum(parts[k] for k in measured)
    any3 = any(parts[k] == 3 for k in measured)
    band = "high" if news2 >= 7 else "medium" if news2 >= 5 else ("low-medium" if any3 else "low")

    q = {"resp_ge_22": None if vals["resp"] is None else vals["resp"] >= 22,
         "sbp_le_100": None if vals["sbp"] is None else vals["sbp"] <= 100,
         "altered_mentation": None if vals["consciousness"] is None else vals["consciousness"] != "alert"}
    qsofa = sum(1 for x in q.values() if x)
    lactate = o.get("lactate")
    infection = o.get("suspected_infection")

    why = []
    if news2 >= 5:
        why.append(f"NEWS2 {news2}" + (" (partial)" if missing else ""))
    elif any3:
        why.append("one vital in the red zone (NEWS2 parameter = 3)")
    if qsofa >= 2:
        why.append(f"qSOFA {qsofa}/3")
    if lactate is not None and lactate >= 2:
        why.append(f"lactate {lactate:g} mmol/L")
    if infection:
        why.append("suspected infection flagged by clinician")
    agrees = bool(why)

    return {
        "news2": news2, "news2_band": band, "news2_partial": bool(missing),
        "news2_parts": {k: parts[k] for k in PARAMS}, "values": vals,
        "measured": measured, "missing": missing, "missing_names": [PARAM_NAMES[k] for k in missing],
        "qsofa": qsofa, "qsofa_parts": q, "lactate": lactate, "suspected_infection": bool(infection),
        "agrees": agrees, "agree_reasons": why,
        "summary": ("Bedside criteria SUPPORT the alert: " + "; ".join(why)) if agrees else
                   ("Bedside criteria do not (yet) support the alert" +
                    (f" – missing: {', '.join(PARAM_NAMES[k] for k in missing)}" if missing else "")),
    }


def suggested_checks(c):
    """Prompts for clinical review (generic, per local protocol) - not treatment instructions."""
    s = []
    if c["values"]["sbp"] is None or c["values"]["resp"] is None or c["values"]["consciousness"] is None:
        miss = [n for k, n in (("sbp", "blood pressure"), ("resp", "respiratory rate"), ("consciousness", "consciousness/confusion"))
                if c["values"][k] is None]
        s.append("Record " + ", ".join(miss) + " in SeptiSense")
    if c["lactate"] is None:
        s.append("Consider a lactate measurement")
    s.append("Review for a source of infection")
    s.append("Follow the local sepsis screening protocol")
    return s
