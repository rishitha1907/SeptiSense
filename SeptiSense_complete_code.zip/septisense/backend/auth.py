"""Simple login for the demo: doctor accounts see everything; patient/guardian accounts see only
their own patient. Passwords are salted PBKDF2 hashes; sessions are random tokens in an
HttpOnly cookie. Good enough for a hackathon prototype - not production security (no HTTPS,
no rate limiting, no password reset).

Default doctor account (change with env vars before demo day):
    SEPTI_DOCTOR_USER=doctor   SEPTI_DOCTOR_PASS=septisense
"""
import hashlib
import os
import secrets
import time

from . import db

SESSION_HOURS = 12
COOKIE = "ss_token"

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  username TEXT PRIMARY KEY, pw_hash TEXT, salt TEXT, role TEXT, patient_id INTEGER, display_name TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, username TEXT, expires REAL);
"""


def _hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 120_000).hex()


def init():
    with db._write_lock:
        db.conn().executescript(SCHEMA)
        db.conn().commit()
    user = os.getenv("SEPTI_DOCTOR_USER", "doctor")
    if not db.q1("SELECT 1 FROM users WHERE username=?", (user,)):
        create_user(user, os.getenv("SEPTI_DOCTOR_PASS", "septisense"), "doctor", None, "Doctor")


def create_user(username, password, role, patient_id=None, display_name=None):
    username = username.strip().lower()
    if not username or not password:
        raise ValueError("username and password required")
    if db.q1("SELECT 1 FROM users WHERE username=?", (username,)):
        raise ValueError("username already taken")
    salt = secrets.token_hex(16)
    db.x("INSERT INTO users VALUES (?,?,?,?,?,?,?)",
         (username, _hash(password, salt), salt, role, patient_id, display_name or username, time.time()))


def login(username, password):
    u = db.q1("SELECT * FROM users WHERE username=?", ((username or "").strip().lower(),))
    if not u or not secrets.compare_digest(u["pw_hash"], _hash(password or "", u["salt"])):
        return None
    token = secrets.token_urlsafe(32)
    db.x("INSERT INTO sessions VALUES (?,?,?)", (token, u["username"], time.time() + SESSION_HOURS * 3600))
    return token


def logout(token):
    if token:
        db.x("DELETE FROM sessions WHERE token=?", (token,))


def user_from_token(token):
    if not token:
        return None
    s = db.q1("SELECT * FROM sessions WHERE token=? AND expires>?", (token, time.time()))
    if not s:
        return None
    u = db.q1("SELECT username, role, patient_id, display_name FROM users WHERE username=?", (s["username"],))
    return u
