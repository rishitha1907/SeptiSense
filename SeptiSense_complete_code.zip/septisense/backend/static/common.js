/* Shared helpers for all SeptiSense pages: API calls, formatting, theme, SVG line chart, risk forecast panel. */
const API = location.origin;
const LV = {normal: {c: 'var(--good)', i: '●', t: 'Normal'}, watch: {c: 'var(--warn)', i: '▲', t: 'Watch'},
            warning: {c: 'var(--serious)', i: '▲', t: 'Warning'}, critical: {c: 'var(--crit)', i: '◆', t: 'Critical'}};
const LV_TEXT = {
  normal: 'No elevated sepsis risk detected by the model.',
  watch: 'Slightly elevated risk. Continue monitoring.',
  warning: 'Elevated risk. The care team has been notified for review.',
  critical: 'High risk relative to baseline. The care team has been notified for urgent review.'};
const LV_TEXT_PATIENT = {
  normal: 'Everything the system measures looks stable right now.',
  watch: 'The system sees small changes and is watching more closely.',
  warning: 'The system has noticed changes and has informed the care team.',
  critical: 'The system has flagged this to the care team as a priority.'};
const QL = {High: 'var(--good)', Medium: 'var(--warn)', Low: 'var(--crit)'};
const $ = id => document.getElementById(id);
const j = (u, o) => fetch(API + u, o).then(r => {
  if (r.status === 401) { location.href = '/login'; return Promise.reject(r); }
  return r.ok ? r.json() : r.json().then(e => Promise.reject(e), () => Promise.reject(r));
});
const post = (u, b, m = 'POST') => j(u, {method: m, headers: {'content-type': 'application/json'}, body: JSON.stringify(b)});
const fmt = (v, d = 0) => v == null || Number.isNaN(+v) ? '–' : Number(v).toFixed(d);
const pct = (v, d = 1) => v == null ? '–' : (v * 100).toFixed(d);
const tstr = ts => new Date(ts * 1000).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', second: '2-digit'});
const dstr = ts => new Date(ts * 1000).toLocaleString([], {day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'});
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
const badge = lv => { const l = LV[lv] || LV.normal; return `<span class="badge"><span style="color:${l.c}">${l.i}</span>${l.t}</span>`; };
const cssVar = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

/* theme */
try { const t = localStorage.getItem('theme'); if (t) document.documentElement.dataset.theme = t; } catch (e) {}
function toggleTheme(after) {
  const r = document.documentElement, dark = r.dataset.theme ? r.dataset.theme === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
  r.dataset.theme = dark ? 'light' : 'dark'; try { localStorage.setItem('theme', r.dataset.theme); } catch (e) {}
  if (after) after();
}
async function logout() { await fetch('/api/logout', {method: 'POST'}); location.href = '/login'; }

/* risk y-axis: risks are small calibrated probabilities, so scale to the data + thresholds, not 0-100 */
function riskMax(values, thr) {
  const m = Math.max(...values.filter(v => v != null), ...(thr ? Object.values(thr).map(t => t * 100) : [0]), 1);
  return Math.min(100, Math.ceil(m * 1.25));
}

/* ---------- SVG line chart with crosshair tooltip ---------- */
function lineChart(el, series, o = {}) {
  const W = Math.max(el.clientWidth || 560, 260), H = o.h || 190, m = {l: 40, r: 12, t: 12, b: 24};
  const pts = series.flatMap(s => s.pts.filter(p => p.y != null));
  if (!pts.length) { el.innerHTML = `<div class="muted small" style="padding:30px 0;text-align:center">No data yet</div>`; return; }
  let xs = pts.map(p => p.x), ys = pts.map(p => p.y).concat(o.hlines ? o.hlines.map(h => h.y) : []);
  let x0 = Math.min(...xs), x1 = Math.max(...xs); if (x1 === x0) x1 = x0 + 1;
  let y0 = o.ymin ?? Math.min(...ys), y1 = o.ymax ?? Math.max(...ys);
  if (y1 === y0) { y0 -= 1; y1 += 1; } const pad = (y1 - y0) * 0.08; if (o.ymin == null) y0 -= pad; if (o.ymax == null) y1 += pad;
  const X = x => m.l + (x - x0) / (x1 - x0) * (W - m.l - m.r), Y = y => H - m.b - (y - y0) / (y1 - y0) * (H - m.t - m.b);
  let g = '';
  for (let i = 0; i <= 4; i++) { const v = y0 + (y1 - y0) * i / 4;
    g += `<line x1="${m.l}" x2="${W - m.r}" y1="${Y(v)}" y2="${Y(v)}" stroke="var(--grid)"/>`
       + `<text x="${m.l - 6}" y="${Y(v) + 4}" text-anchor="end" font-size="10" fill="var(--muted)">${o.yfmt ? o.yfmt(v) : fmt(v, (y1 - y0) < 5 ? 1 : 0)}</text>`; }
  for (let i = 0; i <= 4; i++) { const v = x0 + (x1 - x0) * i / 4;
    g += `<text x="${X(v)}" y="${H - 6}" text-anchor="middle" font-size="10" fill="var(--muted)">${o.xfmt ? o.xfmt(v) : fmt(v)}</text>`; }
  (o.hlines || []).forEach((h, i) => { if (h.y < y0 || h.y > y1) return;
    g += `<line x1="${m.l}" x2="${W - m.r}" y1="${Y(h.y)}" y2="${Y(h.y)}" stroke="${h.c}" stroke-dasharray="4 4" stroke-width="1.2"/>`
       + `<text x="${m.l + 4 + i * 62}" y="${Y(h.y) - 4}" font-size="10" fill="var(--ink2)">${h.label}</text>`; });
  if (o.vline != null && o.vline >= x0 && o.vline <= x1)
    g += `<line x1="${X(o.vline)}" x2="${X(o.vline)}" y1="${m.t}" y2="${H - m.b}" stroke="var(--ink2)" stroke-dasharray="2 3"/>`
       + `<text x="${X(o.vline) - 4}" y="${H - m.b - 6}" text-anchor="end" font-size="10" fill="var(--ink2)">${o.vlabel || ''}</text>`;
  series.forEach(s => {
    let d = '', pen = false;
    s.pts.forEach(p => { if (p.y == null) { if (!o.connectGaps) pen = false; return; } d += (pen ? 'L' : 'M') + X(p.x).toFixed(1) + ' ' + Y(p.y).toFixed(1); pen = true; });
    g += `<path d="${d}" fill="none" stroke="${s.c}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
    const last = [...s.pts].reverse().find(p => p.y != null);
    if (last) g += `<circle cx="${X(last.x)}" cy="${Y(last.y)}" r="4" fill="${s.c}" stroke="var(--surface)" stroke-width="2"/>`;
  });
  const legend = series.length > 1 ? `<div class="legend">${series.map(s => `<span><i class="sw" style="background:${s.c}"></i>${s.name}</span>`).join('')}</div>` : '';
  el.innerHTML = legend + `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(o.label || '')}">${g}
    <line class="xh" y1="${m.t}" y2="${H - m.b}" stroke="var(--muted)" visibility="hidden"/>
    <rect x="${m.l}" y="${m.t}" width="${W - m.l - m.r}" height="${H - m.t - m.b}" fill="transparent"/></svg><div class="tip"></div>`;
  const svg = el.querySelector('svg'), tip = el.querySelector('.tip'), xh = el.querySelector('.xh');
  svg.addEventListener('mousemove', e => {
    const r = svg.getBoundingClientRect(), sx = (e.clientX - r.left) / r.width * W;
    const xv = x0 + (sx - m.l) / (W - m.l - m.r) * (x1 - x0);
    let rows = [], best = null;
    series.forEach(s => { const v = s.pts.filter(p => p.y != null); if (!v.length) return;
      const p = v.reduce((a, b) => Math.abs(b.x - xv) < Math.abs(a.x - xv) ? b : a);
      best = p.x; rows.push(`<span style="color:${s.c}">■</span> ${s.name}: <b>${o.yfmt ? o.yfmt(p.y) : fmt(p.y, 1)}</b>`); });
    if (best == null) return;
    xh.setAttribute('x1', X(best)); xh.setAttribute('x2', X(best)); xh.setAttribute('visibility', 'visible');
    tip.innerHTML = `<div class="muted">${o.xfmt ? o.xfmt(best) : fmt(best)}</div>` + rows.join('<br>');
    tip.style.display = 'block';
    const left = (X(best) / W) * r.width; tip.style.left = Math.min(left + 10, r.width - tip.offsetWidth) + 'px'; tip.style.top = '10px';
  });
  svg.addEventListener('mouseleave', () => { tip.style.display = 'none'; xh.setAttribute('visibility', 'hidden'); });
}

/* ---------- forecast panel: level banner + next 2h/4h/6h cards + factors ---------- */
function forecastHTML(P, base, opts = {}) {
  if (!P) return `<div class="muted">Waiting for the first prediction (needs at least one complete minute of data).</div>`;
  const l = LV[P.level] || LV.normal, low = P.confidence === 'low';
  const rel = r => base ? (r / base) : null;
  const relTxt = r => { const x = rel(r); if (x == null) return ''; if (x < 0.1) return 'well below the average patient'; return `${x.toFixed(1)}× the average patient`; };
  const maxR = Math.max(P.risk_6h, base ? base * 3 : 0.05);
  const card = (h, r, main) => `<div class="fcard ${main ? 'main' : ''}"><div class="h">Next ${h}</div>
      <div class="p">${pct(r)}<small>%</small></div><div class="rel">${relTxt(r)}</div>
      <div class="track"><div class="fill" style="width:${Math.min(100, Math.max(2, r / maxR * 100))}%"></div></div></div>`;
  return `<div class="${low ? 'lowconf' : ''}">
    ${opts.noLevel ? '' : `<div class="levelbar" style="--lc:${l.c}"><span class="ic">${l.i}</span>
      <div><div class="lt">${l.t}</div><div class="ld">${opts.patient ? LV_TEXT_PATIENT[P.level] : LV_TEXT[P.level]}</div></div>
      <div class="conf">Confidence: <b>${esc(P.confidence)}</b><br>${esc(P.confidence_reason || '')}</div></div>`}
    ${low ? '<div class="warnbox" style="margin:-4px 0 12px"><b>Low confidence – check sensor.</b> Alerts are held until data quality recovers.</div>' : ''}
    <div class="small" style="color:var(--ink2);font-weight:600;margin-bottom:8px">Probability of sepsis onset within…</div>
    <div class="fc">${card('2 hours', P.risk_2h)}${card('4 hours', P.risk_4h)}${card('6 hours', P.risk_6h, true)}</div>
    ${base ? `<div class="note">Average risk across ICU patients in the training data: ${pct(base)}% per 6 h. Risks are calibrated probabilities, so small numbers are expected; the level and the × average matter most.</div>` : ''}
    ${opts.noFactors ? '' : `<div class="small" style="color:var(--ink2);margin-top:14px;font-weight:600">What is driving the 6-hour risk (SHAP)</div>
    <ul class="reasons">${(P.reasons || []).map(r => `<li><span class="ar">${esc(r.arrow)}</span><span>${esc(r.text)}</span><span class="muted small" style="margin-left:auto">${r.contribution > 0 ? 'raises' : 'lowers'} risk</span></li>`).join('') || '<li class="muted">No factors yet</li>'}</ul>`}
    <div class="note">Hour ${P.hour} of monitoring · updated ${tstr(P.ts)}</div></div>`;
}
