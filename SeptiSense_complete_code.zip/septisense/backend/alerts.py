"""Smart alerting (alert-fatigue reduction).

- 3 levels: watch < warning < critical (thresholds from the validation set, see model_info.json).
- Hysteresis: a level is entered only after `consecutive_up` predictions in a row at/above it,
  and left only after `consecutive_down` predictions below it. One noisy reading can't alert.
- Low-confidence predictions (bad sensor data) never escalate an alert.
- Acknowledge / snooze, all logged. Snooze silences notifications, but escalation to CRITICAL
  always notifies (safety override).
- TWO-KEY ROUTING: the ML model is sensitive but has low precision, so before paging a doctor
  we ask whether bedside criteria agree (NEWS2 >= 5 or a red-zone vital, qSOFA >= 2, lactate >= 2,
  or clinician-flagged infection - see clinical.py):
      watch                         -> dashboard only
      warning/critical, criteria NO -> NURSE: "bedside check + enter observations"
      warning/critical, criteria YES-> DOCTOR (+ nurse)
  Escalation chain: nurse alert not acknowledged in `nurse_escalate_sec`  -> doctor;
  new nurse observations that make the criteria agree -> doctor immediately;
  critical, doctor paged, still unacknowledged after `guardian_delay_sec` -> guardian (plain language).
- Every alert stores the clinical snapshot, who was notified and an escalation log.
- Clinicians mark alerts useful / false alarm -> measured precision per routing path.
"""
import json
import time

from . import clinical, db, notify

LEVELS = ["normal", "watch", "warning", "critical"]


class PatientAlertState:
    def __init__(self):
        self.level = "normal"
        self.up = 0
        self.down = 0
        self.pending_level = None
        self.suppressed_blips = 0      # raw crossings that never persisted (noise)
        self.lowconf_holds = 0         # escalations blocked because data quality was low
        self._blip_open = False


class AlertEngine:
    def __init__(self):
        self.state = {}

    def st(self, pid):
        if pid not in self.state:              # after a restart, resume from the last shown level
            s = PatientAlertState()
            last = db.q1("SELECT level FROM predictions WHERE patient_id=? ORDER BY ts DESC LIMIT 1", (pid,))
            if last and last["level"] in LEVELS:
                s.level = last["level"]
            self.state[pid] = s
        return self.state[pid]

    def update(self, patient, pred_row, raw_level, confidence, sim_hour=None, send=True):
        """Called after every prediction. Returns the displayed (hysteresis) level."""
        s = self.st(patient["id"])
        cfg = db.get_settings()
        n_up, n_down = int(cfg["consecutive_up"]), int(cfg["consecutive_down"])
        cur_i, raw_i = LEVELS.index(s.level), LEVELS.index(raw_level)

        if raw_i > cur_i:
            if confidence == "low":
                s.lowconf_holds += 1
                return s.level
            s.down = 0
            s.up += 1
            s._blip_open = True
            if s.up >= n_up:
                self._escalate(patient, s, raw_level, pred_row, cfg, sim_hour, send)
                s.up, s._blip_open = 0, False
        elif raw_i < cur_i:
            if s._blip_open:
                s.suppressed_blips += 1
                s._blip_open = False
            s.up = 0
            s.down += 1
            if s.down >= n_down:
                s.level = raw_level
                s.down = 0
                if raw_level == "normal":
                    db.x("UPDATE alerts SET status='resolved', resolved_at=? WHERE patient_id=? AND status IN ('active','acked','snoozed')",
                         (time.time(), patient["id"]))
        else:
            if s._blip_open:
                s.suppressed_blips += 1
                s._blip_open = False
            s.up = s.down = 0
        return s.level

    def _escalate(self, patient, s, level, pred_row, cfg, sim_hour, send=True):
        s.level = level
        if not cfg["alerts_enabled"]:
            return
        now = time.time()
        prev = db.q1("SELECT * FROM alerts WHERE patient_id=? AND status IN ('active','acked','snoozed') ORDER BY ts DESC LIMIT 1",
                     (patient["id"],))
        snoozed = prev is not None and prev["status"] == "snoozed" and (prev["snooze_until"] or 0) > now
        if prev:
            db.x("UPDATE alerts SET status='superseded', resolved_at=? WHERE id=?", (now, prev["id"]))
        c = clinical.assess(patient)
        two_key = bool(cfg.get("two_key_enabled", True))
        to_doctor = level in cfg["notify_doctor_levels"] and (c["agrees"] or not two_key)
        to_nurse = level in cfg.get("notify_nurse_levels", ["warning", "critical"])
        routed = "doctor" if to_doctor else ("nurse" if to_nurse else "dashboard")
        log = [{"ts": now, "event": f"raised {level}; bedside criteria {'agree' if c['agrees'] else 'do not agree'}; routed to {routed}"}]
        aid = db.x("INSERT INTO alerts (patient_id, ts, level, risk, reasons, status, sim_hour, routed_to, clinical, escalation_log, "
                   "doctor_notified, doctor_notified_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                   (patient["id"], now, level, pred_row["risk_6h"], pred_row["reasons"], "active", sim_hour, routed,
                    json.dumps(c, ensure_ascii=False), json.dumps(log), int(to_doctor), now if to_doctor else None))
        alert = db.q1("SELECT * FROM alerts WHERE id=?", (aid,))
        roles = []
        if to_doctor and (not snoozed or level == "critical"):
            roles.append("doctor")
        if to_nurse:
            roles.append("nurse")
        if send and roles:
            notify.notify_alert(patient, alert, pred_row, roles)

    def _log(self, alert_id, event):
        a = db.q1("SELECT escalation_log FROM alerts WHERE id=?", (alert_id,))
        log = json.loads((a or {}).get("escalation_log") or "[]")
        log.append({"ts": time.time(), "event": event})
        db.x("UPDATE alerts SET escalation_log=? WHERE id=?", (json.dumps(log), alert_id))

    def _page_doctor(self, a, why):
        p = db.q1("SELECT * FROM patients WHERE id=?", (a["patient_id"],))
        c = clinical.assess(p)
        db.x("UPDATE alerts SET doctor_notified=1, doctor_notified_at=?, routed_to='doctor', clinical=? WHERE id=?",
             (time.time(), json.dumps(c, ensure_ascii=False), a["id"]))
        self._log(a["id"], f"escalated to doctor: {why}")
        a = db.q1("SELECT * FROM alerts WHERE id=?", (a["id"],))
        pred = db.q1("SELECT * FROM predictions WHERE patient_id=? ORDER BY ts DESC LIMIT 1", (a["patient_id"],))
        if p["mode"] == "live" or p["mode"] == "replay":
            notify.notify_alert(p, a, pred, ["doctor"])

    def recheck_after_observation(self, patient):
        """Nurse entered new observations: if the bedside criteria now agree, page the doctor immediately."""
        c = clinical.assess(patient)
        if not c["agrees"]:
            return None
        a = db.q1("SELECT * FROM alerts WHERE patient_id=? AND status='active' AND doctor_notified=0 ORDER BY ts DESC LIMIT 1",
                  (patient["id"],))
        if a:
            self._page_doctor(a, "new bedside observations support the alert (" + "; ".join(c["agree_reasons"]) + ")")
            return a["id"]
        return None

    def check_escalations(self):
        """Run periodically. (1) nurse-routed alert unacknowledged -> doctor. (2) critical, doctor paged,
        still unacknowledged -> guardian."""
        cfg = db.get_settings()
        now = time.time()
        for a in db.q("SELECT * FROM alerts WHERE status='active' AND doctor_notified=0 AND routed_to='nurse' AND ts<=?",
                      (now - int(cfg.get("nurse_escalate_sec", 600)),)):
            p = db.q1("SELECT mode FROM patients WHERE id=?", (a["patient_id"],))
            if p and p["mode"] != "upload":
                sec = int(cfg.get("nurse_escalate_sec", 600))
                self._page_doctor(a, f"not acknowledged by nursing within {sec // 60} min" if sec >= 60 else f"not acknowledged by nursing within {sec} s")
        for a in db.q("SELECT * FROM alerts WHERE status='active' AND guardian_notified=0 AND doctor_notified=1 "
                      "AND COALESCE(doctor_notified_at, ts)<=?", (now - int(cfg["guardian_delay_sec"]),)):
            if a["level"] not in cfg["notify_guardian_levels"]:
                continue
            p = db.q1("SELECT * FROM patients WHERE id=?", (a["patient_id"],))
            if p["mode"] == "upload":
                continue
            pred = db.q1("SELECT * FROM predictions WHERE patient_id=? ORDER BY ts DESC LIMIT 1", (a["patient_id"],))
            db.x("UPDATE alerts SET guardian_notified=1 WHERE id=?", (a["id"],))
            self._log(a["id"], f"guardian informed (critical alert not acknowledged by the doctor within {int(cfg['guardian_delay_sec'])} s)")
            notify.notify_alert(p, a, pred, ["guardian"])

    check_guardian_escalation = check_escalations      # old name used by engine.py

    def stats(self, pid):
        s = self.st(pid)
        return {"display_level": s.level, "suppressed_noise_blips": s.suppressed_blips,
                "low_confidence_holds": s.lowconf_holds, "pending_up_count": s.up}


def _append_log(alert_id, event):
    a = db.q1("SELECT escalation_log FROM alerts WHERE id=?", (alert_id,))
    log = json.loads((a or {}).get("escalation_log") or "[]")
    log.append({"ts": time.time(), "event": event})
    db.x("UPDATE alerts SET escalation_log=? WHERE id=?", (json.dumps(log), alert_id))


def ack(alert_id, by):
    db.x("UPDATE alerts SET status='acked', acked_by=?, acked_at=? WHERE id=?", (by, time.time(), alert_id))
    _append_log(alert_id, f"acknowledged by {by}")
    return db.q1("SELECT * FROM alerts WHERE id=?", (alert_id,))


def snooze(alert_id, minutes, by):
    db.x("UPDATE alerts SET status='snoozed', acked_by=?, acked_at=?, snooze_until=? WHERE id=?",
         (by, time.time(), time.time() + 60 * minutes, alert_id))
    _append_log(alert_id, f"snoozed {minutes} min by {by}")
    return db.q1("SELECT * FROM alerts WHERE id=?", (alert_id,))


def feedback(alert_id, useful, note, by):
    db.x("UPDATE alerts SET feedback=?, feedback_note=?, feedback_by=? WHERE id=?",
         ("useful" if useful else "false_alarm", note, by, alert_id))
    return db.q1("SELECT * FROM alerts WHERE id=?", (alert_id,))


def performance():
    """Real-world alert precision from clinician feedback, split by routing path."""
    rows = db.q("SELECT a.routed_to, a.level, a.feedback, a.doctor_notified FROM alerts a "
                "JOIN patients p ON p.id=a.patient_id WHERE a.status!='superseded' OR a.feedback IS NOT NULL")
    out = {"total_alerts": len(rows), "with_feedback": 0, "useful": 0, "false_alarm": 0, "by_route": {}}
    for r in rows:
        k = r["routed_to"] or "doctor"
        b = out["by_route"].setdefault(k, {"alerts": 0, "useful": 0, "false_alarm": 0})
        b["alerts"] += 1
        if r["feedback"]:
            out["with_feedback"] += 1
            out[r["feedback"]] += 1
            b[r["feedback"]] += 1
    fb = out["useful"] + out["false_alarm"]
    out["precision_from_feedback"] = round(out["useful"] / fb, 3) if fb else None
    for b in out["by_route"].values():
        n = b["useful"] + b["false_alarm"]
        b["precision"] = round(b["useful"] / n, 3) if n else None
    out["doctor_pages_avoided"] = sum(1 for r in rows if (r["routed_to"] == "nurse" and not r["doctor_notified"]))
    return out
