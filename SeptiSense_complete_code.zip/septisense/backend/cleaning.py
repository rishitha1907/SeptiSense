"""Noise handling for ESP telemetry. Three steps:

1. validate_sample()  – per packet: sensor flags (finger off / leads off), valid ranges, spike limit.
2. aggregate_window() – per 60 s window: Hampel outlier removal, MEDIAN (robust to spikes),
                        % valid samples, packet loss from seq gaps, ECG-vs-PPG HR agreement,
                        quality score 0–100 -> High / Medium / Low.
3. ECG helpers        – band-pass + 50 Hz notch filter and R-peak heart rate for raw ECG samples.

Bad data becomes NaN (missing), never 0, so it can't fake a low reading.
"""
import math
from collections import deque

import numpy as np
from scipy import signal

import config

FIELDS = ["hr", "hr_ecg", "spo2", "temp", "resp"]


def _num(v):
    try:
        f = float(v)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None


class DeviceState:
    """Remembers the last accepted value per field so spikes can be detected."""
    def __init__(self):
        self.last = {}           # field -> (ts, value)
        self.rejects = {}        # field -> consecutive spike rejections
        self.ecg = deque(maxlen=500 * 10)
        self.ecg_fs = None       # sample rate: from the packet ("ecg_fs") or estimated from samples/second
        self.last_ecg_ts = None

    COMMON_FS = (100, 125, 128, 200, 250, 256, 300, 360, 500)

    def update_fs(self, n_samples, ts, given_fs=None):
        if given_fs:
            self.ecg_fs = int(given_fs)
        elif self.last_ecg_ts is not None and 0.3 < ts - self.last_ecg_ts < 5:
            est = n_samples / (ts - self.last_ecg_ts)
            snapped = min(self.COMMON_FS, key=lambda f: abs(f - est))
            self.ecg_fs = snapped if self.ecg_fs is None else (snapped if abs(snapped - est) < abs(self.ecg_fs - est) * 0.8 else self.ecg_fs)
        elif self.ecg_fs is None:
            self.ecg_fs = min(self.COMMON_FS, key=lambda f: abs(f - n_samples))   # assume ~1 packet per second
        self.last_ecg_ts = ts
        return self.ecg_fs


def validate_sample(pkt, st: DeviceState):
    """Returns (clean dict, list of flags)."""
    flags, clean = [], {}
    ts = pkt["ts"]
    finger_on = pkt.get("finger_on")
    leads_off = pkt.get("leads_off")
    for f in FIELDS:
        v = _num(pkt.get(f))
        if v is None:
            clean[f] = None
            continue
        if f in ("hr", "spo2") and finger_on is False:
            clean[f] = None; flags.append("no_finger") if "no_finger" not in flags else None
            continue
        if f == "hr_ecg" and leads_off:
            clean[f] = None; flags.append("leads_off")
            continue
        if f == "spo2" and v == 0:            # many MAX3010x libs output 0 / -999 for invalid
            clean[f] = None; flags.append("spo2_invalid")
            continue
        lo, hi = config.VALID_RANGES[f]
        if not lo <= v <= hi:
            clean[f] = None; flags.append(f"{f}_out_of_range")
            continue
        prev = st.last.get(f)
        if prev is not None:
            dt = max(ts - prev[0], 1.0)
            if dt <= 10 and abs(v - prev[1]) > config.MAX_RATE_PER_SEC[f] * dt:
                st.rejects[f] = st.rejects.get(f, 0) + 1
                if st.rejects[f] < 3:          # 3 rejections in a row = it's a real change, accept
                    clean[f] = None; flags.append(f"{f}_spike")
                    continue
        st.rejects[f] = 0
        st.last[f] = (ts, v)
        clean[f] = v
    return clean, flags


def hampel(x, k=3.0):
    """Remove points further than k * scaled-MAD from the median. Returns (kept, n_removed)."""
    x = np.asarray([v for v in x if v is not None], dtype=float)
    if len(x) < 5:
        return x, 0
    med = np.median(x)
    mad = 1.4826 * np.median(np.abs(x - med))
    if mad == 0:
        return x, 0
    keep = np.abs(x - med) <= k * mad
    return x[keep], int((~keep).sum())


def aggregate_window(rows, window_sec=config.WINDOW_SEC, covered_sec=None):
    """rows: telemetry rows (dicts with *_c cleaned values + seq) for ONE patient and ONE window.
    covered_sec: part of the window the patient was actually being monitored (first window can be partial)."""
    span_sec = min(window_sec, covered_sec) if covered_sec else window_sec
    expected = max(int(span_sec * config.EXPECTED_PACKET_HZ), 1)
    out = {"n_packets": len(rows)}
    seqs = sorted({r["seq"] for r in rows if r.get("seq") is not None})
    if len(seqs) >= 2:
        span = seqs[-1] - seqs[0] + 1
        out["packet_loss"] = round(1 - len(seqs) / span, 3) if span > 0 else 0.0
    else:
        out["packet_loss"] = round(1 - len(rows) / expected, 3) if rows else 1.0
    out["packet_loss"] = max(0.0, out["packet_loss"])

    outliers = 0
    ecg_present = any(r.get("hr_ecg") is not None for r in rows)
    for f, key in [("hr", "hr_c"), ("hr_ecg", "hr_ecg_c"), ("spo2", "spo2_c"), ("temp", "temp_c"), ("resp", "resp_c")]:
        vals, removed = hampel([r.get(key) for r in rows])
        outliers += removed
        valid_frac = len(vals) / expected
        if f in ("hr", "spo2", "temp", "hr_ecg"):
            out[f"valid_{'ecg' if f == 'hr_ecg' else f}"] = round(min(valid_frac, 1.0), 3)
        out[f] = float(np.median(vals)) if len(vals) and valid_frac >= config.MIN_VALID_FRACTION else None
    out["outliers"] = outliers
    out["temp_skin"] = out.pop("temp")
    out["temp_core"] = round(out["temp_skin"] + config.SKIN_TO_CORE_OFFSET, 2) if out["temp_skin"] is not None else None

    if out["hr"] is not None and out["hr_ecg"] is not None:
        out["hr_agree"] = int(abs(out["hr"] - out["hr_ecg"]) <= config.HR_AGREEMENT_BPM)
    else:
        out["hr_agree"] = None

    # quality score: weighted, only over the parts that exist in this setup
    parts = [(0.25, out["valid_hr"]), (0.20, out["valid_spo2"]), (0.15, out["valid_temp"]),
             (0.20, 1 - out["packet_loss"])]
    if ecg_present:
        parts.append((0.10, out["valid_ecg"]))
    if out["hr_agree"] is not None:
        parts.append((0.10, float(out["hr_agree"])))
    w = sum(p[0] for p in parts)
    q = 100 * sum(p[0] * p[1] for p in parts) / w
    if out["hr_agree"] == 0:
        q = min(q, 60)                       # sensors disagree -> can't be High
    out["quality"] = round(q, 1)
    out["quality_level"] = "High" if q >= 80 else ("Medium" if q >= 50 else "Low")
    return out


# ---------------- ECG ----------------
def filter_ecg(x, fs=250):
    """0.5–40 Hz band-pass (baseline wander + EMG noise) and 50 Hz notch (Indian mains hum)."""
    x = np.asarray(x, dtype=float)
    if len(x) < fs * 2:
        return x
    b, a = signal.butter(2, [0.5, 40], btype="band", fs=fs)
    y = signal.filtfilt(b, a, x)
    bn, an = signal.iirnotch(50, 30, fs=fs)
    return signal.filtfilt(bn, an, y)


def ecg_heart_rate(x, fs=250):
    """R-peak based HR (bpm) from a few seconds of ECG; None if the signal is unusable."""
    if len(x) < fs * 4:
        return None
    y = filter_ecg(x, fs)
    y = y if abs(y.max()) >= abs(y.min()) else -y          # handle inverted leads
    peaks, _ = signal.find_peaks(y, distance=int(0.3 * fs), height=np.percentile(y, 90) * 0.6)
    if len(peaks) < 3:
        return None
    rr = np.diff(peaks) / fs
    rr = rr[(rr > 0.27) & (rr < 2.0)]
    if len(rr) < 2 or np.std(rr) / np.mean(rr) > 0.35:      # too irregular -> probably noise
        return None
    return round(60 / np.median(rr), 1)
