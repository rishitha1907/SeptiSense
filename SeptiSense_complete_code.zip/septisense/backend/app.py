"""SeptiSense backend (FastAPI). Run from the project root:

    uvicorn backend.app:app --host 0.0.0.0 --port 8000

ESP posts telemetry to  http://<laptop-ip>:8000/api/telemetry
Dashboard (reference UI) at  http://localhost:8000/
API docs (auto)            at  http://localhost:8000/docs
"""
import json
import re
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional, Union

import numpy as np
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, model_validator

import config
from . import alerts as alerts_mod
from . import auth, clinical, db, notify, report, upload
from .cleaning import DeviceState, ecg_heart_rate, filter_ecg, validate_sample
from .engine import Engine

ENGINE: Engine = None
DEVICES = {}           # device_id -> DeviceState (spike memory + ECG buffer)


@asynccontextmanager
async def lifespan(app):
    global ENGINE
    db.init()
    auth.init()
    ENGINE = Engine()
    ENGINE.start()
    yield
    ENGINE.stop()

app = FastAPI(title="SeptiSense API", version="1.0", lifespan=lifespan,
              description=config.DISCLAIMER)
STATIC = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC), name="static")

# ---------------- access control ----------------
OPEN_PATHS = {"/login", "/api/login", "/api/telemetry", "/api/health", "/favicon.ico"}
PATIENT_API = re.compile(r"^/api/patients/(\d+)/(latest|predictions|predictions\.csv|hourly|vitals|alerts|summary|report)$")
PATIENT_OK = {"/patient", "/api/me", "/api/logout", "/api/model", "/"}


@app.middleware("http")
async def require_login(request: Request, call_next):
    path = request.url.path
    if path in OPEN_PATHS or path.startswith("/static/"):
        return await call_next(request)
    user = auth.user_from_token(request.cookies.get(auth.COOKIE))
    is_api = path.startswith("/api/") or path in ("/docs", "/openapi.json")
    if not user:
        return JSONResponse({"detail": "login required"}, status_code=401) if is_api else RedirectResponse("/login")
    if user["role"] == "patient":                      # patients/guardians: only their own patient
        own = str(user["patient_id"])
        m = PATIENT_API.match(path)
        rep_m = re.match(r"^/report/(\d+)$", path)
        ok = path in PATIENT_OK or (m and m.group(1) == own) or (rep_m and rep_m.group(1) == own)
        if not ok:
            return JSONResponse({"detail": "not allowed"}, status_code=403) if is_api else RedirectResponse("/patient")
    request.state.user = user
    return await call_next(request)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ======================= schemas =======================
PACKET_ALIASES = {      # accept the field names different firmware versions use
    "hr": ["hr", "hr_ppg", "HR_ppg", "HR", "heart_rate", "bpm", "pulse"],
    "hr_ecg": ["hr_ecg", "HR_ecg", "ecg_hr", "ecg_bpm"],
    "spo2": ["spo2", "SpO2", "SPO2", "o2sat", "O2Sat"],
    "temp": ["temp", "Temp", "temperature", "temp_c", "skin_temp"],
    "resp": ["resp", "rr", "resp_rate"],
    "finger_on": ["finger_on", "finger", "fingerOn", "finger_present"],
    "leads_off": ["leads_off", "leadsOff", "lead_off", "lo"],
    "ecg": ["ecg", "ecg_raw", "ecg_samples_data", "ecg_data"],
    "ecg_fs": ["ecg_fs", "fs", "ecg_rate", "sample_rate"],
    "seq": ["seq", "sequence", "counter", "id_seq"],
    "ts": ["ts", "timestamp", "time", "epoch"],
    "device_id": ["device_id", "device", "deviceId", "id"],
    "device_alert": ["alert", "device_alert", "local_alert", "buzzer"],
}


class Packet(BaseModel):
    model_config = ConfigDict(extra="ignore")

    @model_validator(mode="before")
    @classmethod
    def _aliases(cls, v):
        if not isinstance(v, dict):
            return v
        out = dict(v)
        for key, names in PACKET_ALIASES.items():
            if out.get(key) is None:
                for n in names:
                    if v.get(n) is not None:
                        out[key] = v[n]
                        break
        if out.get("device_id") is None:
            out["device_id"] = "esp32-01"
        out["device_id"] = str(out["device_id"])
        if isinstance(out.get("ecg"), (int, float)):      # a count, not samples
            out["ecg"] = None
        if isinstance(out.get("ecg"), list):
            out["ecg"] = [x for x in out["ecg"] if isinstance(x, (int, float))]
        for k in ("hr", "hr_ecg", "spo2", "temp", "resp", "ts", "ecg_fs", "seq"):   # never reject a packet for one bad field
            val = out.get(k)
            if val is None or isinstance(val, (int, float)) and not isinstance(val, bool):
                continue
            try:
                out[k] = float(val)
            except (TypeError, ValueError):
                out[k] = None
        if out.get("seq") is not None:
            out["seq"] = int(out["seq"])
        for k in ("finger_on", "leads_off", "device_alert", "buffered"):
            val = out.get(k)
            if isinstance(val, str):
                out[k] = val.strip().lower() in ("1", "true", "yes", "on")
            elif isinstance(val, (int, float)):
                out[k] = bool(val)
        return out

    device_id: str
    device_alert: Optional[bool] = None
    seq: Optional[int] = None
    ts: Optional[float] = None          # unix seconds from NTP (ms also accepted)
    hr: Optional[float] = None          # PPG heart rate (MAX30102)
    hr_ecg: Optional[float] = None      # ECG heart rate if computed on the ESP
    spo2: Optional[float] = None
    temp: Optional[float] = None        # SKIN temperature, °C
    resp: Optional[float] = None
    finger_on: Optional[bool] = None
    leads_off: Optional[bool] = None
    ecg: Optional[List[float]] = None   # optional raw ECG samples since last packet
    ecg_fs: Optional[float] = None    # sample rate; estimated from samples/second if not sent
    buffered: Optional[bool] = False    # True if this was stored offline and sent late


class PatientIn(BaseModel):
    name: str
    age: Optional[float] = None
    gender: Optional[int] = None        # 1 = male, 0 = female (dataset convention)
    device_id: Optional[str] = None
    login_username: Optional[str] = None   # optional patient/guardian login
    login_password: Optional[str] = None


class LoginIn(BaseModel):
    username: str
    password: str


class UploadIn(BaseModel):
    name: str
    csv_text: str
    filename: Optional[str] = None
    age: Optional[float] = None
    gender: Optional[int] = None


class UserIn(BaseModel):
    username: str
    password: str
    display_name: Optional[str] = None


class PatientUpdate(BaseModel):
    name: Optional[str] = None
    age: Optional[float] = None
    gender: Optional[int] = None
    device_id: Optional[str] = None
    active: Optional[int] = None


class ContactIn(BaseModel):
    role: str                           # 'doctor' or 'guardian'
    name: str
    telegram_chat_id: Optional[str] = None


class ObsIn(BaseModel):
    sbp: Optional[float] = None               # systolic blood pressure, mmHg
    resp: Optional[float] = None              # respiratory rate, /min (counted)
    consciousness: Optional[str] = None       # 'alert' | 'confused' | 'voice' | 'pain' | 'unresponsive'
    on_oxygen: Optional[bool] = None
    suspected_infection: Optional[bool] = None
    lactate: Optional[float] = None           # mmol/L
    wbc: Optional[float] = None               # x10^9/L
    note: Optional[str] = None


class FeedbackIn(BaseModel):
    useful: bool
    note: Optional[str] = None


class AckIn(BaseModel):
    by: str = "doctor"


class SnoozeIn(BaseModel):
    by: str = "doctor"
    minutes: Optional[int] = None


class ReplayIn(BaseModel):
    demo_pid: str
    seconds_per_hour: float = 3.0
    name: Optional[str] = None


# ======================= telemetry =======================
def _patient_for_device(device_id):
    p = db.q1("SELECT * FROM patients WHERE device_id=? AND active=1 AND mode='live' ORDER BY id DESC LIMIT 1", (device_id,))
    if p:
        return p
    now = time.time()
    pid = db.x("INSERT INTO patients (name,age,gender,device_id,mode,created_at,monitor_start) VALUES (?,?,?,?,?,?,?)",
               (f"Patient on {device_id}", None, None, device_id, "live", now, now))
    return db.q1("SELECT * FROM patients WHERE id=?", (pid,))


def _fix_ts(ts, recv):
    if ts is None:
        return recv, "ts_from_server"
    if ts > 1e12:
        ts = ts / 1000.0
    if ts < 1.6e9 or ts > recv + 60 or ts < recv - 86400:     # NTP not synced / clock wrong
        return recv, "ts_from_server"
    return ts, None


@app.post("/api/telemetry")
def telemetry(body: Union[Packet, List[Packet]]):
    """Accepts one packet or a list (offline buffer flush). Response has 'ack' (highest seq stored)
    and 'level' (current alert level) so the ESP can drive its local buzzer."""
    pkts = body if isinstance(body, list) else [body]
    recv = time.time()
    rows, max_seq, patient = [], None, None
    for pk in pkts:
        st = DEVICES.setdefault(pk.device_id, DeviceState())
        patient = _patient_for_device(pk.device_id)
        ts, tsflag = _fix_ts(pk.ts, recv)
        d = pk.model_dump()
        d["ts"] = ts
        if pk.ecg:
            fs = st.update_fs(len(pk.ecg), ts, pk.ecg_fs)
            st.ecg.extend(pk.ecg)
            if not pk.leads_off:     # our own filtered R-peak HR is preferred over the device value when available
                server_hr = ecg_heart_rate(np.array(list(st.ecg)[-int(fs * 8):]), fs)
                if server_hr is not None:
                    d["hr_ecg"] = server_hr
        clean, flags = validate_sample(d, st)
        if tsflag:
            flags.append(tsflag)
        if pk.buffered:
            flags.append("buffered")
        rows.append((pk.device_id, patient["id"], pk.seq, ts, recv, d.get("hr"), d.get("hr_ecg"), d.get("spo2"), d.get("temp"),
                     d.get("resp"), None if pk.finger_on is None else int(pk.finger_on),
                     None if pk.leads_off is None else int(pk.leads_off),
                     clean["hr"], clean["hr_ecg"], clean["spo2"], clean["temp"], clean["resp"], ",".join(flags),
                     json.dumps([round(float(x), 4) for x in pk.ecg]) if pk.ecg else None,
                     st.ecg_fs if pk.ecg else None, None if pk.device_alert is None else int(pk.device_alert)))
        ENGINE.mark_dirty(patient["id"], ts)
        if pk.seq is not None:
            max_seq = pk.seq if max_seq is None else max(max_seq, pk.seq)
    db.xmany("""INSERT INTO telemetry (device_id,patient_id,seq,ts,recv_ts,hr,hr_ecg,spo2,temp,resp,finger_on,leads_off,
                hr_c,hr_ecg_c,spo2_c,temp_c,resp_c,flags,ecg,ecg_fs,device_alert) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", rows)
    level = ENGINE.alerts.st(patient["id"]).level if patient else "normal"
    return {"ack": max_seq, "accepted": len(rows), "server_ts": recv, "level": level}


# ======================= patients =======================
@app.get("/api/patients")
def list_patients():
    ps = db.q("SELECT * FROM patients ORDER BY id DESC")
    for p in ps:
        p["display_level"] = ENGINE.alerts.st(p["id"]).level
    return ps


@app.post("/api/patients")
def create_patient(p: PatientIn):
    if p.device_id:   # one active live patient per device
        db.x("UPDATE patients SET active=0 WHERE device_id=? AND mode='live'", (p.device_id,))
    if p.login_username and db.q1("SELECT 1 FROM users WHERE username=?", (p.login_username.strip().lower(),)):
        raise HTTPException(400, "that login username is already taken")
    now = time.time()
    pid = db.x("INSERT INTO patients (name,age,gender,device_id,mode,created_at,monitor_start) VALUES (?,?,?,?,?,?,?)",
               (p.name, p.age, p.gender, p.device_id, "live", now, now))
    if p.login_username and p.login_password:
        auth.create_user(p.login_username, p.login_password, "patient", pid, p.name)
    return db.q1("SELECT * FROM patients WHERE id=?", (pid,))


@app.put("/api/patients/{pid}")
def update_patient(pid: int, u: PatientUpdate):
    for k, v in u.model_dump(exclude_none=True).items():
        db.x(f"UPDATE patients SET {k}=? WHERE id=?", (v, pid))
    return db.q1("SELECT * FROM patients WHERE id=?", (pid,))


def _patient(pid):
    p = db.q1("SELECT * FROM patients WHERE id=?", (pid,))
    if not p:
        raise HTTPException(404, "patient not found")
    return p


def _pred_out(r):
    if not r:
        return None
    r = dict(r)
    r["reasons"] = json.loads(r["reasons"] or "[]")
    return r


@app.get("/api/patients/{pid}/latest")
def latest(pid: int):
    """Everything the dashboard's top panel needs in one call."""
    p = _patient(pid)
    now = time.time()
    last_pkt = db.q1("SELECT * FROM telemetry WHERE patient_id=? ORDER BY recv_ts DESC LIMIT 1", (pid,))
    recent = db.q("SELECT * FROM telemetry WHERE patient_id=? AND recv_ts>=? ORDER BY ts", (pid, now - 15))

    def med(col):
        v = [r[col] for r in recent if r[col] is not None]
        return round(float(np.median(v)), 1) if v else None
    win = db.q1("SELECT * FROM windows WHERE patient_id=? ORDER BY start_ts DESC LIMIT 1", (pid,))
    online = bool(last_pkt) and now - last_pkt["recv_ts"] <= config.OFFLINE_AFTER_SEC
    temp_skin = med("temp_c")
    flags = sorted({f for r in recent for f in (r["flags"] or "").split(",") if f})
    pred = db.q1("SELECT * FROM predictions WHERE patient_id=? ORDER BY ts DESC LIMIT 1", (pid,))
    return {
        "patient": p,
        "connectivity": {"online": online if p["mode"] == "live" else None,
                         "last_packet_age_sec": round(now - last_pkt["recv_ts"], 1) if last_pkt else None,
                         "packets_last_15s": len(recent)},
        "vitals_now": {"hr": med("hr_c"), "hr_ecg": med("hr_ecg_c"), "spo2": med("spo2_c"), "temp_skin": temp_skin,
                       "temp_core_est": round(temp_skin + config.SKIN_TO_CORE_OFFSET, 1) if temp_skin is not None else None,
                       "resp": med("resp_c")} if p["mode"] == "live" else _last_known_hourly(pid),
        "data_quality": ({"score": win["quality"], "level": win["quality_level"], "packet_loss": win["packet_loss"],
                          "valid_hr": win["valid_hr"], "valid_spo2": win["valid_spo2"], "valid_temp": win["valid_temp"],
                          "hr_agree": win["hr_agree"], "outliers_removed": win["outliers"], "window_start": win["start_ts"]}
                         if win else None),
        "live_flags": flags,
        "prediction": _pred_out(pred),
        "baseline_risk_6h": report.baseline_rate(),
        "clinical": clinical.assess(p),
        "alert_state": ENGINE.alerts.stats(pid),
        "thresholds": db.get_settings().get("threshold_override") or (ENGINE.model.thresholds if ENGINE.model else None),
        "model_loaded": ENGINE.model is not None,
        "model_error": ENGINE.model_error,
        "disclaimer": config.DISCLAIMER,
    }


def _last_known_hourly(pid):
    """Replay: latest non-missing value of each vital (dataset vitals are not measured every hour)."""
    out = {}
    for col, key in [("HR", "hr"), ("O2Sat", "spo2"), ("Temp", "temp_core_est"), ("Resp", "resp")]:
        r = db.q1(f"SELECT {col} v FROM hourly WHERE patient_id=? AND {col} IS NOT NULL ORDER BY hour DESC LIMIT 1", (pid,))
        out[key] = round(r["v"], 1) if r else None
    return out


@app.get("/api/patients/{pid}/raw")
def raw(pid: int, seconds: int = 120):
    """1 Hz cleaned samples for live charts."""
    rows = db.q("SELECT ts,hr_c hr,hr_ecg_c hr_ecg,spo2_c spo2,temp_c temp,resp_c resp,flags FROM telemetry "
                "WHERE patient_id=? AND ts>=? ORDER BY ts", (pid, time.time() - seconds))
    return rows


@app.get("/api/patients/{pid}/vitals")
def vitals(pid: int, minutes: int = 60):
    """Per-minute cleaned windows (median values + quality) for trend charts."""
    return db.q("SELECT * FROM windows WHERE patient_id=? AND start_ts>=? ORDER BY start_ts", (pid, time.time() - 60 * minutes))


@app.get("/api/patients/{pid}/hourly")
def hourly(pid: int):
    return db.q("SELECT * FROM hourly WHERE patient_id=? ORDER BY hour", (pid,))


@app.get("/api/patients/{pid}/predictions")
def predictions(pid: int, limit: int = 500):
    rows = db.q("SELECT * FROM predictions WHERE patient_id=? ORDER BY ts DESC LIMIT ?", (pid, limit))
    return [_pred_out(r) for r in reversed(rows)]


@app.get("/api/patients/{pid}/alerts")
def patient_alerts(pid: int):
    rows = db.q("SELECT * FROM alerts WHERE patient_id=? ORDER BY ts DESC", (pid,))
    for r in rows:
        r["reasons"] = json.loads(r["reasons"] or "[]")
        r["clinical"] = json.loads(r.get("clinical") or "null")
        r["escalation_log"] = json.loads(r.get("escalation_log") or "[]")
    return rows


@app.get("/api/patients/{pid}/notifications")
def patient_notifications(pid: int):
    return db.q("SELECT * FROM notifications WHERE patient_id=? ORDER BY ts DESC LIMIT 100", (pid,))


@app.get("/api/patients/{pid}/summary", response_class=PlainTextResponse)
def summary(pid: int):
    s = report.summary_text(pid)
    if s is None:
        raise HTTPException(404, "patient not found")
    return s


@app.get("/api/patients/{pid}/report")
def patient_report(pid: int):
    r = report.build(pid)
    if r is None:
        raise HTTPException(404, "patient not found")
    return r


@app.post("/api/patients/{pid}/login")
def add_patient_login(pid: int, l: LoginIn, request: Request):
    _patient(pid)
    try:
        auth.create_user(l.username, l.password, "patient", pid, None)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "username": l.username.strip().lower()}


@app.get("/api/patients/{pid}/predictions.csv")
def predictions_csv(pid: int):
    import pandas as pd
    p = _patient(pid)
    preds = pd.DataFrame(db.q("SELECT hour, risk_2h, risk_4h, risk_6h, level, confidence FROM predictions WHERE patient_id=? ORDER BY ts", (pid,)))
    hrs = pd.DataFrame(db.q("SELECT hour, HR, O2Sat, Temp, Resp FROM hourly WHERE patient_id=? ORDER BY hour", (pid,)))
    if preds.empty:
        raise HTTPException(404, "no predictions yet")
    out = preds.merge(hrs, on="hour", how="left") if not hrs.empty else preds
    if p["mode"] != "live":
        out = out.drop_duplicates("hour", keep="last")
    name = re.sub(r"[^A-Za-z0-9_-]+", "_", p["name"])[:40] or "patient"
    return PlainTextResponse(out.to_csv(index=False, float_format="%.4f"), media_type="text/csv",
                             headers={"Content-Disposition": f'attachment; filename="septisense_{name}_risk.csv"'})


@app.get("/api/patients/{pid}/observations")
def get_observations(pid: int):
    return db.q("SELECT * FROM observations WHERE patient_id=? ORDER BY ts DESC LIMIT 100", (pid,))


@app.post("/api/patients/{pid}/observations")
def add_observation(pid: int, o: ObsIn, request: Request):
    """Nurse/doctor bedside observations. Feed the clinical score (NEWS2/qSOFA) - not the ML model."""
    p = _patient(pid)
    lim = {"sbp": (40, 260), "resp": (2, 70), "lactate": (0, 30), "wbc": (0, 200)}
    for k, (lo, hi) in lim.items():
        v = getattr(o, k)
        if v is not None and not lo <= v <= hi:
            raise HTTPException(400, f"{k} = {v} looks implausible (expected {lo}-{hi})")
    if o.consciousness and o.consciousness not in ("alert", "confused", "voice", "pain", "unresponsive"):
        raise HTTPException(400, "consciousness must be alert, confused, voice, pain or unresponsive")
    last_h = db.q1("SELECT MAX(hour) h FROM hourly WHERE patient_id=?", (pid,))
    db.x("INSERT INTO observations (patient_id,ts,hour,sbp,resp,consciousness,on_oxygen,suspected_infection,lactate,wbc,note,entered_by) "
         "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
         (pid, time.time(), last_h["h"] if last_h else None, o.sbp, o.resp, o.consciousness,
          None if o.on_oxygen is None else int(o.on_oxygen), None if o.suspected_infection is None else int(o.suspected_infection),
          o.lactate, o.wbc, o.note, request.state.user.get("display_name")))
    escalated = ENGINE.alerts.recheck_after_observation(p)
    return {"clinical": clinical.assess(p), "escalated_alert_id": escalated}


@app.get("/api/patients/{pid}/contacts")
def contacts(pid: int):
    return db.q("SELECT * FROM contacts WHERE patient_id=?", (pid,))


@app.post("/api/patients/{pid}/contacts")
def add_contact(pid: int, c: ContactIn):
    if c.role not in ("doctor", "nurse", "guardian"):
        raise HTTPException(400, "role must be doctor, nurse or guardian")
    cid = db.x("INSERT INTO contacts (patient_id,role,name,telegram_chat_id) VALUES (?,?,?,?)", (pid, c.role, c.name, c.telegram_chat_id))
    return db.q1("SELECT * FROM contacts WHERE id=?", (cid,))


@app.delete("/api/contacts/{cid}")
def del_contact(cid: int):
    db.x("DELETE FROM contacts WHERE id=?", (cid,))
    return {"ok": True}


# ======================= alerts =======================
@app.get("/api/alerts")
def all_alerts(status: Optional[str] = None):
    sql, args = "SELECT a.*, p.name patient_name FROM alerts a JOIN patients p ON p.id=a.patient_id", ()
    if status:
        sql, args = sql + " WHERE a.status=?", (status,)
    rows = db.q(sql + " ORDER BY a.ts DESC LIMIT 200", args)
    for r in rows:
        r["reasons"] = json.loads(r["reasons"] or "[]")
    return rows


@app.post("/api/alerts/{aid}/ack")
def ack(aid: int, a: AckIn, request: Request):
    return alerts_mod.ack(aid, request.state.user.get("display_name") or a.by)


@app.post("/api/alerts/{aid}/feedback")
def alert_feedback(aid: int, f: FeedbackIn, request: Request):
    return alerts_mod.feedback(aid, f.useful, f.note, request.state.user.get("display_name"))


@app.get("/api/alerts/performance")
def alert_performance():
    return alerts_mod.performance()


@app.post("/api/alerts/{aid}/snooze")
def snooze(aid: int, s: SnoozeIn, request: Request):
    return alerts_mod.snooze(aid, s.minutes or db.get_settings()["snooze_minutes_default"],
                             request.state.user.get("display_name") or s.by)


# ======================= devices / ECG =======================
@app.get("/api/devices")
def devices():
    now = time.time()
    out = []
    for r in db.q("SELECT device_id, MAX(recv_ts) last, COUNT(*) n FROM telemetry GROUP BY device_id"):
        lastw = db.q1("SELECT w.* FROM windows w JOIN patients p ON p.id=w.patient_id WHERE p.device_id=? ORDER BY start_ts DESC LIMIT 1",
                      (r["device_id"],))
        out.append({"device_id": r["device_id"], "online": now - r["last"] <= config.OFFLINE_AFTER_SEC,
                    "last_seen_sec": round(now - r["last"], 1), "packets_total": r["n"],
                    "packet_loss_last_window": lastw["packet_loss"] if lastw else None,
                    "quality_last_window": lastw["quality_level"] if lastw else None})
    return out


@app.get("/api/devices/{device_id}/ecg")
def ecg(device_id: str, seconds: int = 5):
    st = DEVICES.get(device_id)
    if not st or not st.ecg:
        return {"fs": None, "samples": [], "hr_ecg": None}
    full = np.array(st.ecg)
    fs = st.ecg_fs or 250
    n = int(fs * seconds)
    edge = int(fs * 0.4)                 # drop filter edge effects at the newest end
    y = filter_ecg(full, fs)[:-edge] if len(full) > n + edge else filter_ecg(full, fs)
    y = y[-n:]
    x = full[-n:]
    return {"fs": fs, "samples": [round(float(v), 4) for v in y], "hr_ecg": ecg_heart_rate(x, fs)}


@app.get("/api/devices/{device_id}/recent")
def device_recent(device_id: str, n: int = 40, seconds: int = 180):
    """Raw + cleaned packets for the Device monitor page."""
    now = time.time()
    rows = db.q("SELECT id, seq, ts, recv_ts, hr, hr_c, hr_ecg, hr_ecg_c, spo2, spo2_c, temp, temp_c, finger_on, leads_off, "
                "device_alert, flags, ecg_fs, CASE WHEN ecg IS NULL THEN 0 ELSE length(ecg) - length(replace(ecg, ',', '')) + 1 END ecg_n "
                "FROM telemetry WHERE device_id=? AND recv_ts>=? ORDER BY recv_ts DESC, id DESC LIMIT 2000",
                (device_id, now - seconds))
    last60 = [r for r in rows if r["recv_ts"] >= now - 60]
    seqs = sorted({r["seq"] for r in last60 if r["seq"] is not None})
    loss = round(100 * (1 - len(seqs) / (seqs[-1] - seqs[0] + 1)), 1) if len(seqs) >= 2 else None
    lags = [r["recv_ts"] - r["ts"] for r in last60 if r["ts"]]
    total = db.q1("SELECT COUNT(*) n, MIN(recv_ts) first FROM telemetry WHERE device_id=?", (device_id,))
    flag_counts = {}
    for r in last60:
        for f in (r["flags"] or "").split(","):
            if f:
                flag_counts[f] = flag_counts.get(f, 0) + 1
    st = DEVICES.get(device_id)
    return {
        "device_id": device_id,
        "online": bool(rows) and now - rows[0]["recv_ts"] <= config.OFFLINE_AFTER_SEC,
        "last_seen_sec": round(now - rows[0]["recv_ts"], 1) if rows else None,
        "packets_last_60s": len(last60), "packet_loss_pct_60s": loss,
        "median_lag_ms": round(1000 * float(np.median(lags))) if lags else None,
        "ecg_fs": st.ecg_fs if st else None,
        "total_packets": total["n"], "recording_since": total["first"],
        "flags_last_60s": flag_counts,
        "rows": rows[:n], "series": list(reversed(rows)),
    }


def _csv_response(df, filename):
    return PlainTextResponse(df.to_csv(index=False), media_type="text/csv",
                             headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.get("/api/devices/{device_id}/telemetry.csv")
def device_csv(device_id: str, minutes: int = 0):
    """Saved raw + cleaned telemetry (one row per packet). minutes=0 -> everything."""
    import pandas as pd
    since = time.time() - minutes * 60 if minutes else 0
    rows = db.q("SELECT seq, ts, recv_ts, hr AS hr_ppg_raw, hr_c AS hr_ppg_clean, hr_ecg AS hr_ecg_raw, hr_ecg_c AS hr_ecg_clean, "
                "spo2 AS spo2_raw, spo2_c AS spo2_clean, temp AS temp_skin_raw, temp_c AS temp_skin_clean, finger_on, leads_off, "
                "device_alert, flags, ecg_fs FROM telemetry WHERE device_id=? AND recv_ts>=? ORDER BY ts", (device_id, since))
    df = pd.DataFrame(rows)
    if df.empty:
        raise HTTPException(404, "no data for this device")
    df.insert(1, "time", pd.to_datetime(df["ts"], unit="s", utc=True).dt.tz_convert("Asia/Kolkata").dt.strftime("%Y-%m-%d %H:%M:%S.%f").str[:-3])
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", device_id)
    return _csv_response(df, f"septisense_{safe}_telemetry.csv")


@app.get("/api/devices/{device_id}/ecg.csv")
def device_ecg_csv(device_id: str, minutes: int = 10):
    """Saved raw ECG, one row per sample (time reconstructed from packet time + sample rate)."""
    import pandas as pd
    since = time.time() - minutes * 60 if minutes else 0
    rows = db.q("SELECT seq, ts, ecg, ecg_fs FROM telemetry WHERE device_id=? AND recv_ts>=? AND ecg IS NOT NULL ORDER BY ts",
                (device_id, since))
    out = []
    for r in rows:
        x = json.loads(r["ecg"]); fs = r["ecg_fs"] or 250
        for i, v in enumerate(x):
            out.append((r["seq"], round(r["ts"] - (len(x) - 1 - i) / fs, 4), v))
    if not out:
        raise HTTPException(404, "no ECG saved for this device")
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", device_id)
    return _csv_response(pd.DataFrame(out, columns=["seq", "t_unix", "ecg"]), f"septisense_{safe}_ecg.csv")


@app.get("/device")
def device_page():
    return FileResponse(STATIC / "device.html")


# ======================= settings / model =======================
@app.get("/api/settings")
def get_settings():
    return db.get_settings()


@app.put("/api/settings")
def put_settings(d: dict):
    return db.set_settings(d)


@app.get("/api/model")
def model_card():
    if not ENGINE.model:
        return {"loaded": False, "error": ENGINE.model_error}
    info = dict(ENGINE.model.info)
    mpath = config.ARTIFACTS / "metrics.json"
    info["metrics"] = json.loads(mpath.read_text(encoding="utf-8")) if mpath.exists() else None
    info["loaded"] = True
    return info


@app.get("/api/model/plots/{name}")
def model_plot(name: str):
    f = config.ARTIFACTS / f"{Path(name).stem}.png"
    if not f.exists():
        raise HTTPException(404)
    return FileResponse(f)


# ======================= telegram / replay =======================
@app.get("/api/telegram/updates")
def tg_updates():
    return notify.telegram_updates()


@app.post("/api/upload")
def upload_csv(u: UploadIn):
    """Upload a vitals CSV -> every hour is scored by the model; returns the new patient + parsing notes."""
    if not ENGINE.model:
        raise HTTPException(400, ENGINE.model_error)
    if len(u.csv_text) > 5_000_000:
        raise HTTPException(400, "File too large (max 5 MB).")
    try:
        hourly_df, meta, notes = upload.parse(u.csv_text)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Could not read the file: {e}")
    age = u.age if u.age is not None else meta.get("age")
    gender = u.gender if u.gender is not None else meta.get("gender")
    if age is None:
        notes.append("No age given - the model's age feature is treated as unknown.")
    pid = ENGINE.analyse_upload(hourly_df, u.name or (u.filename or "Uploaded patient"), age, gender,
                                meta.get("onset_hour"), u.filename)
    return {"patient": db.q1("SELECT * FROM patients WHERE id=?", (pid,)), "hours": int(len(hourly_df)), "notes": notes}


@app.get("/api/upload/sample")
def upload_sample():
    """A ready-to-try CSV built from one held-out septic test patient (hour, HR, SpO2, Temp)."""
    import pandas as pd
    f = config.ARTIFACTS / "demo_patients.csv"
    if not f.exists():
        raise HTTPException(404, "train the model first")
    d = pd.read_csv(f, dtype={"pid": str})
    sep = d[d["septic_patient"] == 1]
    d = (sep if not sep.empty else d)
    d = d[d["pid"] == d["pid"].iloc[0]]
    out = d[["hour", "HR", "O2Sat", "Temp"]].rename(columns={"O2Sat": "SpO2"})
    return PlainTextResponse(out.to_csv(index=False, float_format="%.1f"), media_type="text/csv",
                             headers={"Content-Disposition": 'attachment; filename="septisense_sample_upload.csv"'})


@app.get("/api/users")
def list_users():
    return db.q("SELECT u.username, u.role, u.display_name, u.patient_id, p.name patient_name, u.created_at "
                "FROM users u LEFT JOIN patients p ON p.id=u.patient_id ORDER BY u.role, u.username")


@app.post("/api/users")
def add_doctor(u: UserIn):
    """Create another doctor/staff account (patient logins are created per patient)."""
    if len(u.password) < 6:
        raise HTTPException(400, "password must be at least 6 characters")
    try:
        auth.create_user(u.username, u.password, "doctor", None, u.display_name or u.username)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@app.get("/api/replay/demos")
def replay_demos():
    import pandas as pd
    f = config.ARTIFACTS / "demo_patients.csv"
    if not f.exists():
        return []
    d = pd.read_csv(f, dtype={"pid": str})
    g = d.groupby("pid").agg(hours=("hour", "count"), septic=("septic_patient", "max"), onset_hour=("t_sepsis", "first"),
                             age=("Age", "first"), gender=("Gender", "first")).reset_index()
    return json.loads(g.to_json(orient="records"))


@app.post("/api/replay/start")
def replay_start(r: ReplayIn):
    if not ENGINE.model:
        raise HTTPException(400, ENGINE.model_error)
    try:
        pid = ENGINE.start_replay(r.demo_pid, r.seconds_per_hour, r.name)
    except ValueError as e:
        raise HTTPException(404, str(e))
    return db.q1("SELECT * FROM patients WHERE id=?", (pid,))


# ======================= dashboard =======================
@app.get("/")
def index(request: Request):
    if request.state.user["role"] == "patient":
        return RedirectResponse("/patient")
    return FileResponse(STATIC / "index.html")


@app.get("/login")
def login_page():
    return FileResponse(STATIC / "login.html")


@app.get("/patient")
def patient_page():
    return FileResponse(STATIC / "patient.html")


@app.get("/report/{pid}")
def report_page(pid: int):
    return FileResponse(STATIC / "report.html")


@app.post("/api/login")
def do_login(l: LoginIn):
    token = auth.login(l.username, l.password)
    if not token:
        raise HTTPException(401, "wrong username or password")
    u = auth.user_from_token(token)
    resp = JSONResponse({"ok": True, "role": u["role"], "redirect": "/" if u["role"] == "doctor" else "/patient"})
    resp.set_cookie(auth.COOKIE, token, httponly=True, samesite="lax", max_age=auth.SESSION_HOURS * 3600)
    return resp


@app.post("/api/logout")
def do_logout(request: Request):
    auth.logout(request.cookies.get(auth.COOKIE))
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.COOKIE)
    return resp


@app.get("/api/me")
def me(request: Request):
    return request.state.user


@app.get("/api/health")
def health():
    return {"ok": True, "model_loaded": ENGINE.model is not None, "time": time.time()}
