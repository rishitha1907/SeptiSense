"""SQLite storage. One file (septisense.db), WAL mode so the API and the background loop
can read/write at the same time."""
import json
import sqlite3
import threading
import time

import config

_local = threading.local()
_write_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS patients (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, age REAL, gender INTEGER,
  device_id TEXT, mode TEXT DEFAULT 'live', created_at REAL, monitor_start REAL,
  replay_source TEXT, replay_onset_hour REAL, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS contacts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, role TEXT, name TEXT, telegram_chat_id TEXT);
CREATE TABLE IF NOT EXISTS telemetry (
  id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT, patient_id INTEGER, seq INTEGER,
  ts REAL, recv_ts REAL,
  hr REAL, hr_ecg REAL, spo2 REAL, temp REAL, resp REAL, finger_on INTEGER, leads_off INTEGER,
  hr_c REAL, hr_ecg_c REAL, spo2_c REAL, temp_c REAL, resp_c REAL, flags TEXT);
CREATE INDEX IF NOT EXISTS ix_tel_pt ON telemetry(patient_id, ts);
CREATE INDEX IF NOT EXISTS ix_tel_dev ON telemetry(device_id, recv_ts);
CREATE TABLE IF NOT EXISTS windows (
  patient_id INTEGER, start_ts REAL, n_packets INTEGER,
  hr REAL, hr_ecg REAL, spo2 REAL, temp_skin REAL, temp_core REAL, resp REAL,
  valid_hr REAL, valid_spo2 REAL, valid_temp REAL, valid_ecg REAL, packet_loss REAL,
  hr_agree INTEGER, outliers INTEGER, quality REAL, quality_level TEXT,
  PRIMARY KEY (patient_id, start_ts));
CREATE TABLE IF NOT EXISTS hourly (
  patient_id INTEGER, hour INTEGER, HR REAL, O2Sat REAL, Temp REAL, Resp REAL,
  n_windows INTEGER, quality REAL, source TEXT, PRIMARY KEY (patient_id, hour));
CREATE TABLE IF NOT EXISTS predictions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, ts REAL, hour INTEGER,
  risk_2h REAL, risk_4h REAL, risk_6h REAL, level_raw TEXT, level TEXT,
  confidence TEXT, confidence_reason TEXT, reasons TEXT);
CREATE INDEX IF NOT EXISTS ix_pred_pt ON predictions(patient_id, ts);
CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, ts REAL, level TEXT, risk REAL,
  reasons TEXT, status TEXT, acked_by TEXT, acked_at REAL, snooze_until REAL,
  guardian_notified INTEGER DEFAULT 0, resolved_at REAL, sim_hour INTEGER);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, patient_id INTEGER, alert_id INTEGER,
  channel TEXT, role TEXT, recipient TEXT, message TEXT, ok INTEGER, info TEXT);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS observations (
  id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER, ts REAL, hour INTEGER,
  sbp REAL, resp REAL, consciousness TEXT, on_oxygen INTEGER, suspected_infection INTEGER,
  lactate REAL, wbc REAL, note TEXT, entered_by TEXT);
"""

DEFAULT_SETTINGS = {
    "alerts_enabled": True,
    "consecutive_up": config.ALERT_CONSECUTIVE_UP,
    "consecutive_down": config.ALERT_CONSECUTIVE_DOWN,
    "notify_doctor_levels": ["warning", "critical"],
    "notify_guardian_levels": ["critical"],
    "guardian_delay_sec": config.GUARDIAN_ESCALATE_SEC,
    "snooze_minutes_default": config.SNOOZE_MIN_DEFAULT,
    "threshold_override": None,   # e.g. {"watch":0.1,"warning":0.2,"critical":0.35}
    "two_key_enabled": True,      # page the doctor only if bedside criteria (NEWS2/qSOFA/lactate) agree
    "notify_nurse_levels": ["warning", "critical"],
    "nurse_escalate_sec": 600,    # nurse-routed alert not acknowledged -> doctor
}


def conn():
    c = getattr(_local, "c", None)
    if c is None:
        c = sqlite3.connect(config.DB_PATH, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        _local.c = c
    return c


MIGRATIONS = [   # columns added after the first release - applied to existing databases
    "ALTER TABLE telemetry ADD COLUMN ecg TEXT",
    "ALTER TABLE telemetry ADD COLUMN ecg_fs REAL",
    "ALTER TABLE telemetry ADD COLUMN device_alert INTEGER",
    "ALTER TABLE alerts ADD COLUMN routed_to TEXT",
    "ALTER TABLE alerts ADD COLUMN doctor_notified_at REAL",
    "ALTER TABLE alerts ADD COLUMN doctor_notified INTEGER DEFAULT 0",
    "ALTER TABLE alerts ADD COLUMN clinical TEXT",
    "ALTER TABLE alerts ADD COLUMN feedback TEXT",
    "ALTER TABLE alerts ADD COLUMN feedback_note TEXT",
    "ALTER TABLE alerts ADD COLUMN feedback_by TEXT",
    "ALTER TABLE alerts ADD COLUMN escalation_log TEXT",
]


def init():
    with _write_lock:
        conn().executescript(SCHEMA)
        for m in MIGRATIONS:
            table = m.split("ALTER TABLE ")[1].split()[0]
            col = m.split("ADD COLUMN ")[1].split()[0]
            have = {r[1] for r in conn().execute(f"PRAGMA table_info({table})").fetchall()}
            if col not in have:
                conn().execute(m)
        for k, v in DEFAULT_SETTINGS.items():
            conn().execute("INSERT OR IGNORE INTO settings VALUES (?, ?)", (k, json.dumps(v)))
        conn().commit()


def q(sql, params=()):
    return [dict(r) for r in conn().execute(sql, params).fetchall()]


def q1(sql, params=()):
    r = conn().execute(sql, params).fetchone()
    return dict(r) if r else None


def x(sql, params=()):
    with _write_lock:
        cur = conn().execute(sql, params)
        conn().commit()
        return cur.lastrowid


def xmany(sql, rows):
    with _write_lock:
        conn().executemany(sql, rows)
        conn().commit()


def get_settings():
    return {r["key"]: json.loads(r["value"]) for r in q("SELECT * FROM settings")}


def set_settings(d):
    for k, v in d.items():
        if k in DEFAULT_SETTINGS:
            x("INSERT OR REPLACE INTO settings VALUES (?, ?)", (k, json.dumps(v)))
    return get_settings()


def now():
    return time.time()
