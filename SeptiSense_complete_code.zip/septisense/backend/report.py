"""Structured patient report (used by the report page, the patient page and the text summary).
Everything is built from stored data with templates - deterministic, no LLM."""
import json
import time

import numpy as np

import config
from . import clinical, db

LEVEL_TEXT = {
    "normal":   ("Normal",   "No elevated sepsis risk detected by the model."),
    "watch":    ("Watch",    "Slightly elevated risk. Continue monitoring."),
    "warning":  ("Warning",  "Elevated risk. The care team has been notified for review."),
    "critical": ("Critical", "High risk relative to baseline. The care team has been notified for urgent review."),
}
LEVEL_TEXT_PATIENT = {
    "normal":   "Everything the system measures looks stable right now.",
    "watch":    "The system sees small changes and is watching more closely.",
    "warning":  "The system has noticed changes and has informed the care team.",
    "critical": "The system has flagged this to the care team as a priority.",
}
VITALS = [("HR", "Heart rate", " bpm", 0, (60, 100)), ("O2Sat", "SpO₂", "%", 0, (95, 100)),
          ("Temp", "Temperature", "°C", 1, (36.1, 37.8)), ("Resp", "Resp. rate", " /min", 0, (12, 20))]


def baseline_rate():
    """Average 6h positive rate in the held-out test set = the 'average patient' risk."""
    try:
        m = json.loads((config.ARTIFACTS / "metrics.json").read_text(encoding="utf-8"))
        return float(m["positive_rate_test"][f"{config.MAIN_HORIZON}h"])
    except Exception:
        return None


def relative(risk, base):
    if risk is None or not base:
        return None
    return round(risk / base, 1)


def build(pid):
    p = db.q1("SELECT * FROM patients WHERE id=?", (pid,))
    if not p:
        return None
    base = baseline_rate()
    hourly = db.q("SELECT * FROM hourly WHERE patient_id=? ORDER BY hour", (pid,))
    preds = db.q("SELECT * FROM predictions WHERE patient_id=? ORDER BY ts", (pid,))
    alerts = db.q("SELECT * FROM alerts WHERE patient_id=? ORDER BY ts", (pid,))
    last = preds[-1] if preds else None

    status = None
    if last:
        lvl = last["level"]
        earlier = [x for x in preds if x["hour"] is not None and last["hour"] is not None and x["hour"] <= last["hour"] - 6]
        delta = (last["risk_6h"] - earlier[-1]["risk_6h"]) if earlier else None
        if delta is None:
            trend = "not enough history yet"
        elif abs(delta) < 0.002:
            trend = "stable"
        else:
            trend = "rising" if delta > 0 else "falling"
        status = {
            "level": lvl, "level_label": LEVEL_TEXT[lvl][0], "level_text": LEVEL_TEXT[lvl][1],
            "patient_text": LEVEL_TEXT_PATIENT[lvl],
            "risk": {h: last[f"risk_{h}"] for h in ("2h", "4h", "6h")},
            "relative": {h: relative(last[f"risk_{h}"], base) for h in ("2h", "4h", "6h")},
            "confidence": last["confidence"], "confidence_reason": last["confidence_reason"],
            "trend": trend, "trend_delta_points": None if delta is None else round(delta * 100, 1),
            "hour": last["hour"], "updated": last["ts"],
            "factors": json.loads(last["reasons"] or "[]"),
        }

    vitals = []
    for col, name, unit, dec, (lo, hi) in VITALS:
        vals = [h[col] for h in hourly if h[col] is not None]
        if not vals:
            continue
        latest = vals[-1]
        rd = (lambda x: round(float(x), dec)) if dec else (lambda x: int(round(float(x))))
        vitals.append({"key": col, "name": name, "unit": unit, "decimals": dec, "normal": [lo, hi],
                       "latest": rd(latest), "min": rd(min(vals)), "max": rd(max(vals)),
                       "mean": rd(np.mean(vals)), "n_hours": len(vals),
                       "flag": "high" if latest > hi else ("low" if latest < lo else "normal")})

    al = [{"time": a["ts"], "hour": a["sim_hour"], "level": a["level"], "risk": a["risk"], "status": a["status"],
           "acked_by": a["acked_by"], "acked_at": a["acked_at"], "reasons": json.loads(a["reasons"] or "[]"),
           "routed_to": a.get("routed_to"), "doctor_notified": a.get("doctor_notified"), "feedback": a.get("feedback"),
           "clinical": json.loads(a.get("clinical") or "null"), "escalation_log": json.loads(a.get("escalation_log") or "[]")}
          for a in alerts]
    obs = db.q("SELECT * FROM observations WHERE patient_id=? ORDER BY ts", (pid,))
    wq = db.q1("SELECT AVG(quality) q, SUM(quality_level='Low') low, COUNT(*) n, AVG(packet_loss) loss FROM windows WHERE patient_id=?", (pid,))
    dq = None
    if wq and wq["n"]:
        dq = {"avg_quality": round(wq["q"], 1), "low_windows": wq["low"], "windows": wq["n"],
              "avg_packet_loss_pct": round(100 * (wq["loss"] or 0), 1)}
    try:
        info = json.loads((config.ARTIFACTS / "model_info.json").read_text(encoding="utf-8"))
        ms = info["metrics_summary"]
        model = {"horizons": list(ms), "auroc": {h: v["auroc"] for h, v in ms.items()},
                 "auprc": {h: v["auprc"] for h, v in ms.items()}, "thresholds": info["thresholds"],
                 "dataset": "PhysioNet/CinC Challenge 2019 (40,336 ICU patients)"}
    except Exception:
        model = None

    started = p["monitor_start"]
    return {
        "patient": {"id": p["id"], "name": p["name"], "age": p["age"],
                    "sex": None if p["gender"] is None else ("Male" if p["gender"] == 1 else "Female"),
                    "mode": p["mode"], "device_id": p["device_id"], "replay_onset_hour": p["replay_onset_hour"]},
        "generated_at": time.time(), "monitoring_started": started, "hours_of_data": len(hourly),
        "baseline_risk_6h": base, "status": status, "vitals": vitals,
        "alerts": al, "alerts_summary": {
            "total": len(al), "acknowledged": sum(1 for a in al if a["acked_at"]),
            "highest": max((a["level"] for a in al), key=["watch", "warning", "critical"].index) if al else None},
        "data_quality": dq, "model": model, "disclaimer": config.DISCLAIMER,
        "clinical": clinical.assess(p), "observations": obs,
    }


def summary_text(pid):
    r = build(pid)
    if r is None:
        return None
    p, s = r["patient"], r["status"]
    who = p["name"] + (f" · {p['age']:.0f} y" if p["age"] is not None else "") + (f" · {p['sex']}" if p["sex"] else "")
    src = {"replay": "replay of a held-out dataset patient", "upload": "uploaded CSV file"}.get(p["mode"], "live sensors")
    L = [f"PATIENT SUMMARY – {who}", f"Data: {r['hours_of_data']} hour(s) of monitoring ({src}).", ""]
    if s:
        rel = s["relative"]["6h"]
        L += ["STATUS",
              f"  Alert level: {s['level_label'].upper()} – {s['level_text']}",
              f"  Sepsis risk in the next 6 h: {s['risk']['6h'] * 100:.1f}%"
              + (f" ({rel}× the average ICU patient's risk)" if rel else ""),
              f"  Next 2 h: {s['risk']['2h'] * 100:.1f}%   Next 4 h: {s['risk']['4h'] * 100:.1f}%",
              f"  Trend over the last 6 h: {s['trend']}"
              + (f" ({s['trend_delta_points']:+.1f} points)" if s["trend_delta_points"] is not None else ""),
              f"  Confidence: {s['confidence']} ({s['confidence_reason']})", ""]
        if s["factors"]:
            L.append("WHAT IS DRIVING THE RISK")
            L += [f"  {f['arrow']} {f['text']}" for f in s["factors"]]
            L.append("")
    c = r["clinical"]
    L.append("BEDSIDE SCORES")
    L.append(f"  NEWS2 {c['news2']} ({c['news2_band']} risk band)" + (f" – partial, missing: {', '.join(c['missing_names'])}" if c["news2_partial"] else ""))
    L.append(f"  qSOFA {c['qsofa']}/3" + (f" · lactate {c['lactate']:g} mmol/L" if c["lactate"] is not None else "")
             + (" · suspected infection flagged" if c["suspected_infection"] else ""))
    L.append(f"  {c['summary']}")
    L.append("")
    if r["vitals"]:
        L.append("VITALS (latest · range · normal range)")
        for v in r["vitals"]:
            tag = "" if v["flag"] == "normal" else f"  ← {v['flag'].upper()}"
            L.append(f"  {v['name']}: {v['latest']}{v['unit']} · {v['min']}–{v['max']}{v['unit']} · "
                     f"{v['normal'][0]}–{v['normal'][1]}{v['unit']}{tag}")
        L.append("")
    a = r["alerts_summary"]
    L.append("ALERTS")
    L.append(f"  {a['total']} raised, highest {a['highest'].upper()}, {a['acknowledged']} acknowledged." if a["total"] else "  None raised.")
    if a["total"]:
        nurse_only = sum(1 for x in r["alerts"] if x["routed_to"] == "nurse" and not x["doctor_notified"])
        if nurse_only:
            L.append(f"  {nurse_only} handled as bedside checks by nursing (bedside criteria did not support paging the doctor).")
    if r["data_quality"]:
        d = r["data_quality"]
        L += ["", "DATA QUALITY", f"  Average {d['avg_quality']}/100; {d['low_windows']} of {d['windows']} one-minute windows low quality; "
              f"average packet loss {d['avg_packet_loss_pct']}%."]
    L += ["", r["disclaimer"]]
    return "\n".join(L)
