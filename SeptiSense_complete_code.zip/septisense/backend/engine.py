"""Background processing:
 telemetry --(60 s windows, cleaning)--> windows --(hourly medians)--> hourly --(model)--> predictions --> alerts

Late packets (ESP offline buffer flushed after Wi-Fi comes back) mark their windows 'dirty',
so those windows and hours are recomputed - buffered data is not lost.
"""
import json
import math
import threading
import time
import traceback

import numpy as np
import pandas as pd

import config
from ml.predict import SepsisModel
from . import db
from .alerts import AlertEngine
from .cleaning import aggregate_window

LEVELS = ["normal", "watch", "warning", "critical"]


def _nan(v):
    return None if v is None or (isinstance(v, float) and math.isnan(v)) else v


class Engine:
    def __init__(self):
        self.model = None
        self.model_error = None
        try:
            self.model = SepsisModel(config.ARTIFACTS)
        except Exception as e:
            self.model_error = f"Model not loaded ({e}). Run: python -m ml.train --data <path>"
            print("[engine]", self.model_error)
        self.alerts = AlertEngine()
        self.dirty = {}                 # patient_id -> set(window_start)
        self.lock = threading.Lock()
        self.replays = {}               # patient_id -> thread
        self._stop = threading.Event()

    # ---------------- ingestion hook ----------------
    def mark_dirty(self, pid, ts):
        w = math.floor(ts / config.WINDOW_SEC) * config.WINDOW_SEC
        with self.lock:
            self.dirty.setdefault(pid, set()).add(w)

    # ---------------- windows + hourly ----------------
    def process_windows(self):
        now = time.time()
        with self.lock:
            work = {pid: sorted(ws) for pid, ws in self.dirty.items()}
            self.dirty = {pid: {w for w in ws if w + config.WINDOW_SEC > now - 2} for pid, ws in self.dirty.items()}
        touched = {}
        for pid, ws in work.items():
            for w in ws:
                if w + config.WINDOW_SEC > now - 2:      # window still filling
                    continue
                rows = db.q("SELECT * FROM telemetry WHERE patient_id=? AND ts>=? AND ts<?", (pid, w, w + config.WINDOW_SEC))
                if not rows:
                    continue
                p = db.q1("SELECT monitor_start FROM patients WHERE id=?", (pid,))
                covered = (w + config.WINDOW_SEC) - max(w, p["monitor_start"] if p else w)   # first window may be partial
                a = aggregate_window(rows, covered_sec=covered)
                db.x("""INSERT OR REPLACE INTO windows (patient_id,start_ts,n_packets,hr,hr_ecg,spo2,temp_skin,temp_core,resp,
                        valid_hr,valid_spo2,valid_temp,valid_ecg,packet_loss,hr_agree,outliers,quality,quality_level)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (pid, w, a["n_packets"], a["hr"], a["hr_ecg"], a["spo2"], a["temp_skin"], a["temp_core"], a["resp"],
                      a["valid_hr"], a["valid_spo2"], a["valid_temp"], a["valid_ecg"], a["packet_loss"], a["hr_agree"],
                      a["outliers"], a["quality"], a["quality_level"]))
                touched.setdefault(pid, set()).add(w)
        for pid, ws in touched.items():
            p = db.q1("SELECT * FROM patients WHERE id=?", (pid,))
            for h in {self.hour_of(p, w) for w in ws}:
                self.rebuild_hour(p, h)

    def hour_of(self, p, ts):
        return max(0, int((ts - p["monitor_start"]) // config.HOUR_SEC))

    def rebuild_hour(self, p, h):
        t0 = p["monitor_start"] + h * config.HOUR_SEC
        ws = db.q("SELECT * FROM windows WHERE patient_id=? AND start_ts>=? AND start_ts<? AND quality_level!='Low'",
                  (p["id"], t0, t0 + config.HOUR_SEC))

        def med(col):
            v = [w[col] for w in ws if w[col] is not None]
            return float(np.median(v)) if v else None
        # HR: prefer PPG HR, fall back to ECG HR
        hr = med("hr") if med("hr") is not None else med("hr_ecg")
        q = float(np.mean([w["quality"] for w in ws])) if ws else 0.0
        db.x("INSERT OR REPLACE INTO hourly (patient_id,hour,HR,O2Sat,Temp,Resp,n_windows,quality,source) VALUES (?,?,?,?,?,?,?,?,?)",
             (p["id"], h, hr, med("spo2"), med("temp_core"), med("resp"), len(ws), q, "sensor"))

    # ---------------- prediction ----------------
    def hourly_frame(self, p):
        rows = db.q("SELECT * FROM hourly WHERE patient_id=? ORDER BY hour", (p["id"],))
        if not rows:
            return None
        df = pd.DataFrame(rows)
        full = pd.DataFrame({"hour": range(0, int(df["hour"].max()) + 1)})   # keep gaps as missing hours
        df = full.merge(df, on="hour", how="left")
        for c in ("HR", "O2Sat", "Temp", "Resp"):
            df[c] = pd.to_numeric(df[c], errors="coerce").astype(float)
        df["pid"] = str(p["id"])
        df["Age"] = p["age"] if p["age"] is not None else np.nan
        df["Gender"] = p["gender"] if p["gender"] is not None else np.nan
        return df

    def confidence(self, p):
        """High / medium / low, based on device connectivity, recent data quality and history length."""
        if p["mode"] == "replay":
            return "high", "replayed dataset values"
        last = db.q1("SELECT MAX(recv_ts) t FROM telemetry WHERE patient_id=?", (p["id"],))
        if not last or not last["t"] or time.time() - last["t"] > config.OFFLINE_AFTER_SEC * 6:
            return "low", "device offline"
        recent = db.q("SELECT quality_level FROM windows WHERE patient_id=? ORDER BY start_ts DESC LIMIT 3", (p["id"],))
        if not recent:
            return "low", "no complete data window yet"
        lv = [r["quality_level"] for r in recent]
        if lv[0] == "Low" or lv.count("Low") >= 2:
            return "low", "poor signal quality - check sensor"
        n_hours = db.q1("SELECT COUNT(*) n FROM hourly WHERE patient_id=? AND n_windows>0", (p["id"],))["n"]
        if lv[0] == "Medium":
            return "medium", "signal quality medium"
        if n_hours < 3:
            return "medium", f"only {n_hours}h of history (model uses up to 12h trends)"
        return "high", "good signal, enough history"

    def predict_patient(self, p, sim_hour=None):
        if self.model is None:
            return None
        hf = self.hourly_frame(p)
        if hf is None:
            return None
        res = self.model.predict_latest(hf)
        thr = db.get_settings().get("threshold_override") or self.model.thresholds
        r6 = res["risk"][f"{self.model.main_h}h"]
        raw = "critical" if r6 >= thr["critical"] else "warning" if r6 >= thr["warning"] else "watch" if r6 >= thr["watch"] else "normal"
        conf, why = self.confidence(p)
        reasons = json.dumps(res["reasons"], ensure_ascii=False)
        hour = int(hf["hour"].max())
        pid_row = db.x("""INSERT INTO predictions (patient_id,ts,hour,risk_2h,risk_4h,risk_6h,level_raw,level,confidence,confidence_reason,reasons)
                          VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                       (p["id"], time.time(), hour, res["risk"].get("2h"), res["risk"].get("4h"), r6, raw, raw, conf, why, reasons))
        pred_row = db.q1("SELECT * FROM predictions WHERE id=?", (pid_row,))
        shown = self.alerts.update(p, pred_row, raw, conf, sim_hour=sim_hour)
        db.x("UPDATE predictions SET level=? WHERE id=?", (shown, pid_row))
        pred_row["level"] = shown
        return pred_row

    # ---------------- replay (demo) ----------------
    def start_replay(self, demo_pid, seconds_per_hour=3.0, name=None):
        demo = pd.read_csv(config.ARTIFACTS / "demo_patients.csv", dtype={"pid": str})
        d = demo[demo["pid"] == str(demo_pid)].sort_values("hour")
        if d.empty:
            raise ValueError(f"demo patient {demo_pid} not found")
        onset = d["t_sepsis"].iloc[0]
        pid = db.x("INSERT INTO patients (name,age,gender,device_id,mode,created_at,monitor_start,replay_source,replay_onset_hour) "
                   "VALUES (?,?,?,?,?,?,?,?,?)",
                   (name or f"Replay {demo_pid}", float(d["Age"].iloc[0]), int(d["Gender"].iloc[0]), None, "replay",
                    time.time(), time.time(), str(demo_pid), None if pd.isna(onset) else float(onset)))

        def run():
            p = db.q1("SELECT * FROM patients WHERE id=?", (pid,))
            for _, r in d.iterrows():
                if self._stop.is_set():
                    return
                db.x("INSERT OR REPLACE INTO hourly (patient_id,hour,HR,O2Sat,Temp,Resp,n_windows,quality,source) VALUES (?,?,?,?,?,?,?,?,?)",
                     (pid, int(r["hour"]), _nan(r.get("HR")), _nan(r.get("O2Sat")), _nan(r.get("Temp")),
                      _nan(r.get("Resp")) if "Resp" in r else None, 60, 100.0, "replay"))
                try:
                    self.predict_patient(p, sim_hour=int(r["hour"]))
                except Exception:
                    traceback.print_exc()
                time.sleep(seconds_per_hour)
            db.x("UPDATE patients SET active=0 WHERE id=?", (pid,))
        t = threading.Thread(target=run, daemon=True)
        self.replays[pid] = t
        t.start()
        return pid

    # ---------------- uploaded CSV (historical data) ----------------
    def analyse_upload(self, hourly, name, age=None, gender=None, onset_hour=None, filename=None):
        """Score every hour of an uploaded record in one pass (no waiting like replay).
        Alerts are logged with their hour but NOT pushed to Telegram, since it is historical data."""
        now = time.time()
        pid = db.x("INSERT INTO patients (name,age,gender,device_id,mode,created_at,monitor_start,replay_source,replay_onset_hour,active) "
                   "VALUES (?,?,?,?,?,?,?,?,?,0)",
                   (name, age, gender, None, "upload", now, now, filename, onset_hour))
        db.xmany("INSERT OR REPLACE INTO hourly (patient_id,hour,HR,O2Sat,Temp,Resp,n_windows,quality,source) VALUES (?,?,?,?,?,?,?,?,?)",
                 [(pid, int(r.hour), _nan(r.HR), _nan(r.O2Sat), _nan(r.Temp), _nan(r.Resp), 60, 100.0, "upload")
                  for r in hourly.itertuples()])
        p = db.q1("SELECT * FROM patients WHERE id=?", (pid,))
        hf = self.hourly_frame(p)
        feats = self.model.featurize(hf)
        risks = self.model.predict_frame(feats)
        X = feats[self.model.features]
        contrib = self.model.boosters[self.model.main_h].predict(X, pred_contrib=True)[:, :-1]
        thr = db.get_settings().get("threshold_override") or self.model.thresholds
        from ml.explain import top_reasons
        hours_with_data = set(int(h) for h in hourly["hour"])
        for i in range(len(feats)):
            hour = int(feats["hour"].iloc[i])
            r = {h: float(risks[h][i]) for h in self.model.horizons}
            r6 = r[self.model.main_h]
            raw = "critical" if r6 >= thr["critical"] else "warning" if r6 >= thr["warning"] else "watch" if r6 >= thr["watch"] else "normal"
            conf, why = ("high", "uploaded record") if hour in hours_with_data else ("low", "no data in this hour of the file")
            reasons = json.dumps(top_reasons(self.model.features, X.iloc[i].tolist(), contrib[i], k=3), ensure_ascii=False)
            row_id = db.x("""INSERT INTO predictions (patient_id,ts,hour,risk_2h,risk_4h,risk_6h,level_raw,level,confidence,confidence_reason,reasons)
                             VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                          (pid, now + hour * 1e-3, hour, r.get(2), r.get(4), r6, raw, raw, conf, why, reasons))
            pred_row = db.q1("SELECT * FROM predictions WHERE id=?", (row_id,))
            shown = self.alerts.update(p, pred_row, raw, conf, sim_hour=hour, send=False)
            db.x("UPDATE predictions SET level=? WHERE id=?", (shown, row_id))
        return pid

    # ---------------- main loop ----------------
    def loop(self):
        last_pred = 0
        while not self._stop.is_set():
            try:
                self.process_windows()
                if time.time() - last_pred >= config.PREDICT_EVERY_SEC:
                    last_pred = time.time()
                    for p in db.q("SELECT * FROM patients WHERE mode='live' AND active=1"):
                        self.predict_patient(p)
                self.alerts.check_escalations()
            except Exception:
                traceback.print_exc()
            self._stop.wait(2.0)

    def start(self):
        threading.Thread(target=self.loop, daemon=True).start()

    def stop(self):
        self._stop.set()
