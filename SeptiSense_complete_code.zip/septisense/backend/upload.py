"""Parse an uploaded vitals CSV into hourly rows the model understands.

Accepted (flexible) columns, case-insensitive:
  time/hour : hour | iculos | time | timestamp | datetime | t   (optional; else 1 row = 1 hour)
  HR        : hr | heart_rate | heartrate | pulse | bpm
  SpO2      : o2sat | spo2 | sp02 | spo2_% | oxygen
  Temp      : temp | temperature | temp_c | temp_f | body_temp
  Resp      : resp | rr | resp_rate | respiratory_rate
  optional  : age, gender/sex, sepsislabel (PhysioNet files - used to mark the true onset)
Delimiters , ; | and tab are auto-detected, so PhysioNet .psv files work too.
Timestamps are grouped into hours (median). Fahrenheit temperatures are converted.
"""
import io

import numpy as np
import pandas as pd

ALIASES = {
    "hour": ["hour", "hours", "iculos", "time", "timestamp", "datetime", "date_time", "t"],
    "HR": ["hr", "heart_rate", "heartrate", "heart rate", "pulse", "bpm"],
    "O2Sat": ["o2sat", "spo2", "sp02", "spo2_%", "spo2(%)", "oxygen", "o2"],
    "Temp": ["temp", "temperature", "temp_c", "temp_f", "body_temp", "temperature_c"],
    "Resp": ["resp", "rr", "resp_rate", "respiratory_rate", "respiration"],
    "Age": ["age"],
    "Gender": ["gender", "sex"],
    "SepsisLabel": ["sepsislabel", "sepsis_label", "sepsis"],
}
RANGES = {"HR": (30, 220), "O2Sat": (50, 100), "Temp": (25, 43), "Resp": (4, 60)}
MAX_HOURS = 2000


def _find(cols, names):
    low = {c.strip().lower(): c for c in cols}
    for n in names:
        if n in low:
            return low[n]
    return None


def parse(text):
    """Returns (hourly_df, meta, notes). hourly_df columns: hour, HR, O2Sat, Temp, Resp."""
    notes = []
    raw = pd.read_csv(io.StringIO(text), sep=None, engine="python")
    if raw.empty:
        raise ValueError("The file has no rows.")
    cols = {k: _find(raw.columns, v) for k, v in ALIASES.items()}
    found = [k for k in ("HR", "O2Sat", "Temp", "Resp") if cols[k]]
    if not found:
        raise ValueError("No vitals columns found. Need at least one of: HR, SpO2, Temp, Resp "
                         f"(found columns: {', '.join(map(str, raw.columns))}).")
    df = pd.DataFrame({k: pd.to_numeric(raw[cols[k]], errors="coerce") for k in found})

    # ---- time -> hour index ----
    if cols["hour"]:
        t = raw[cols["hour"]]
        num = pd.to_numeric(t, errors="coerce")
        if num.notna().mean() > 0.9:
            hours = np.floor(num - num.min()).astype("Int64")
        else:
            dt = pd.to_datetime(t, errors="coerce")
            if dt.notna().mean() < 0.9:
                raise ValueError(f"Could not read the '{cols['hour']}' column as hours or date/time.")
            hours = np.floor((dt - dt.min()).dt.total_seconds() / 3600).astype("Int64")
            notes.append("Timestamps grouped into hourly medians.")
        df["hour"] = hours
    else:
        df["hour"] = np.arange(len(df))
        notes.append("No time column - each row treated as one hour.")
    df = df.dropna(subset=["hour"])

    # ---- units + plausibility ----
    if "Temp" in df and df["Temp"].median() > 50:
        df["Temp"] = (df["Temp"] - 32) * 5 / 9
        notes.append("Temperature looked like °F - converted to °C.")
    for k, (lo, hi) in RANGES.items():
        if k in df:
            bad = ~df[k].between(lo, hi) & df[k].notna()
            if bad.any():
                notes.append(f"{int(bad.sum())} implausible {k} value(s) treated as missing.")
                df.loc[bad, k] = np.nan

    hourly = df.groupby("hour").median(numeric_only=True).reset_index()
    for k in ("HR", "O2Sat", "Temp", "Resp"):
        if k not in hourly:
            hourly[k] = np.nan
    hourly["hour"] = hourly["hour"].astype(int)
    if len(hourly) > MAX_HOURS:
        hourly = hourly.iloc[:MAX_HOURS]
        notes.append(f"Only the first {MAX_HOURS} hours were analysed.")
    missing = [k for k in ("HR", "O2Sat", "Temp") if hourly[k].isna().all()]
    if missing:
        notes.append(f"No data for {', '.join(missing)} - the model treats it as not measured, so results are less reliable.")

    meta = {}
    if cols["Age"]:
        a = pd.to_numeric(raw[cols["Age"]], errors="coerce").dropna()
        if len(a):
            meta["age"] = float(a.iloc[0])
    if cols["Gender"]:
        g = raw[cols["Gender"]].dropna().astype(str).str.strip().str.lower()
        if len(g):
            meta["gender"] = 1 if g.iloc[0] in ("1", "m", "male") else 0 if g.iloc[0] in ("0", "f", "female") else None
    if cols["SepsisLabel"]:
        lab = pd.to_numeric(raw[cols["SepsisLabel"]], errors="coerce")
        pos = lab[lab == 1].index
        if len(pos) and pos[0] in df.index:
            first = int(df.loc[pos[0], "hour"])
            meta["onset_hour"] = first + 6               # PhysioNet labels start 6 h before onset
            notes.append(f"File contains SepsisLabel - true onset marked at hour {first + 6}.")
    return hourly[["hour", "HR", "O2Sat", "Temp", "Resp"]], meta, notes
